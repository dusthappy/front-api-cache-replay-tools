"use strict";
(() => {
  // src/shared/types.ts
  var CHANNEL = "API_CACHE_REPLAY_V1";
  var MAX_BODY_BYTES = 1024 * 1024;
  var BRIDGE_TIMEOUT_MS = 1200;

  // src/content/bridge.ts
  function requestId() {
    if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
    return Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function bridge(type, payload, signal) {
    return new Promise((resolve, reject) => {
      if (signal?.aborted) {
        reject(signal.reason);
        return;
      }
      const id = requestId();
      const finish = (error, data) => {
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        signal?.removeEventListener("abort", onAbort);
        if (error !== void 0) reject(error);
        else resolve(data);
      };
      const onAbort = () => finish(signal?.reason ?? new DOMException("Aborted", "AbortError"));
      const onMessage = (event) => {
        if (event.source !== window || event.origin !== location.origin) return;
        const message = event.data;
        if (message?.channel !== CHANNEL || message.direction !== "to-main" || message.id !== id) return;
        if (message.ok) finish(void 0, message.data);
        else finish(new Error(typeof message.error === "string" ? message.error : "\u6269\u5C55\u6682\u4E0D\u53EF\u7528"));
      };
      const timer = setTimeout(() => finish(new Error("\u6269\u5C55\u8FDE\u63A5\u8D85\u65F6\uFF0C\u5DF2\u76F4\u901A")), BRIDGE_TIMEOUT_MS);
      window.addEventListener("message", onMessage);
      signal?.addEventListener("abort", onAbort, { once: true });
      window.postMessage({ channel: CHANNEL, direction: "to-extension", id, type, payload }, location.origin);
    });
  }

  // src/content/sha256.ts
  var K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var rotate = (value, shift) => value >>> shift | value << 32 - shift;
  function sha256Hex(input) {
    const bytes = new Uint8Array(Math.ceil((input.length + 9) / 64) * 64);
    bytes.set(input);
    bytes[input.length] = 128;
    const view = new DataView(bytes.buffer);
    const bitLength = input.length * 8;
    view.setUint32(bytes.length - 8, Math.floor(bitLength / 4294967296));
    view.setUint32(bytes.length - 4, bitLength >>> 0);
    const state = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
    const words = new Uint32Array(64);
    for (let offset = 0; offset < bytes.length; offset += 64) {
      for (let index = 0; index < 16; index++) words[index] = view.getUint32(offset + index * 4);
      for (let index = 16; index < 64; index++) {
        const a2 = words[index - 15], b2 = words[index - 2];
        const s0 = rotate(a2, 7) ^ rotate(a2, 18) ^ a2 >>> 3;
        const s1 = rotate(b2, 17) ^ rotate(b2, 19) ^ b2 >>> 10;
        words[index] = words[index - 16] + s0 + words[index - 7] + s1 >>> 0;
      }
      let [a, b, c, d, e, f, g, h] = state;
      for (let index = 0; index < 64; index++) {
        const s1 = rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25);
        const choice = e & f ^ ~e & g;
        const t1 = h + s1 + choice + K[index] + words[index] >>> 0;
        const s0 = rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22);
        const majority = a & b ^ a & c ^ b & c;
        const t2 = s0 + majority >>> 0;
        h = g;
        g = f;
        f = e;
        e = d + t1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = t1 + t2 >>> 0;
      }
      const round = [a, b, c, d, e, f, g, h];
      for (let index = 0; index < 8; index++) state[index] = state[index] + round[index] >>> 0;
    }
    return Array.from(state, (word) => word.toString(16).padStart(8, "0")).join("");
  }

  // src/content/request-runtime.ts
  var secret = /authorization|cookie|password|passwd|secret|token|signature|csrf|xsrf|api[-_]?key/i;
  var singleUse = /signature|csrf|xsrf|nonce/i;
  var authPath = /(?:^|\/)(?:login|logout|signin|signout|token|refresh)\/*$/i;
  var credentialHeader = /authorization|token|api[-_]?key/i;
  var identityCookie = /session|(?:^|[-_])sid(?:$|[-_])|auth|token|user|account|tenant/i;
  var encoder = new TextEncoder();
  var templates = /* @__PURE__ */ new Map();
  var currentIdentity = /* @__PURE__ */ new Map();
  var currentTenant = /* @__PURE__ */ new Map();
  var runtimeGeneration = 0;
  var nativeFetch = window.fetch.bind(window);
  function invalidateRuntime(origin) {
    runtimeGeneration++;
    for (const [key, value] of templates) {
      if (!origin || new URL(value.descriptor.url).origin === origin) templates.delete(key);
    }
    if (origin) {
      currentIdentity.delete(origin);
      currentTenant.delete(origin);
    } else {
      currentIdentity.clear();
      currentTenant.clear();
    }
  }
  function runtimeVersion() {
    return runtimeGeneration;
  }
  async function hash(value) {
    if (!crypto.subtle) return sha256Hex(encoder.encode(value));
    const digest = await crypto.subtle.digest("SHA-256", encoder.encode(value));
    return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function safeHeaders(headers) {
    return Object.fromEntries(Array.from(headers).filter(([name]) => !secret.test(name)));
  }
  async function cookieIdentityFor(url, credentials) {
    if (credentials === "omit" || new URL(url).origin !== location.origin) return void 0;
    try {
      const values = document.cookie.split(";").map((value) => value.trim()).filter((value) => {
        const end = value.indexOf("=");
        return end > 0 && identityCookie.test(value.slice(0, end));
      }).sort();
      return hash(JSON.stringify(values));
    } catch {
      return void 0;
    }
  }
  function redactBody(value) {
    if (Array.isArray(value)) return value.map(redactBody);
    if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, secret.test(key) ? "[REDACTED]" : redactBody(item)]));
    return value;
  }
  async function descriptorFor(url, method, headers, body, credentials, pageUrl, startedAt, source = "page", unsupportedReason) {
    const parsed = new URL(url, location.href);
    parsed.hash = "";
    let sensitive = Boolean(parsed.username || parsed.password);
    parsed.username = "";
    parsed.password = "";
    for (const key of new Set(parsed.searchParams.keys())) {
      if (secret.test(key)) {
        sensitive = true;
        parsed.searchParams.set(key, "[REDACTED]");
      }
    }
    let safeBody = body;
    if (body) {
      try {
        const parsedBody = JSON.parse(body);
        const redacted = redactBody(parsedBody);
        if (JSON.stringify(parsedBody) !== JSON.stringify(redacted)) {
          sensitive = true;
          safeBody = JSON.stringify(redacted);
        }
      } catch {
        unsupportedReason ??= "\u4EC5\u652F\u6301 JSON \u8BF7\u6C42\u4F53";
        safeBody = void 0;
      }
    }
    const credentialsInHeaders = Array.from(headers).filter(([name]) => credentialHeader.test(name) && !singleUse.test(name));
    const identityHash = credentialsInHeaders.length === 1 && credentialsInHeaders[0][0] === "authorization" ? await hash(credentialsInHeaders[0][1]) : credentialsInHeaders.length ? await hash(JSON.stringify(credentialsInHeaders)) : void 0;
    const cookieIdentityHash = await cookieIdentityFor(parsed.href, credentials);
    const tenantHeaders = ["x-tenant-id", "x-tenant", "tenant-id", "x-org-id", "x-organization-id", "x-account-id"];
    const tenant = tenantHeaders.filter((name) => headers.has(name)).map((name) => `${name}:${headers.get(name)}`).join("\n");
    const priorIdentity = currentIdentity.get(parsed.origin), priorTenant = currentTenant.get(parsed.origin);
    if (identityHash && priorIdentity && priorIdentity !== identityHash || tenant && priorTenant && priorTenant !== tenant) invalidateRuntime(parsed.origin);
    if (identityHash) currentIdentity.set(parsed.origin, identityHash);
    if (tenant) currentTenant.set(parsed.origin, tenant);
    if (authPath.test(parsed.pathname)) invalidateRuntime(parsed.origin);
    const oneTime = Array.from(headers.keys()).some((name) => singleUse.test(name)) || Array.from(new URL(url, location.href).searchParams.keys()).some((name) => singleUse.test(name));
    return {
      requestId: requestId(),
      pageUrl,
      url: parsed.href,
      method: method.toUpperCase(),
      headers: safeHeaders(headers),
      body: safeBody,
      identityHash,
      cookieIdentityHash,
      source,
      startedAt,
      credentials,
      unsupportedReason: unsupportedReason ?? (sensitive ? "\u8BF7\u6C42\u542B\u654F\u611F\u53C2\u6570\uFF0C\u5DF2\u8131\u654F\u5E76\u76F4\u901A" : oneTime ? "\u8BF7\u6C42\u4F9D\u8D56\u4E00\u6B21\u6027\u7B7E\u540D\u6216 CSRF\uFF0C\u9700\u7531\u9875\u9762\u89E6\u53D1" : void 0)
    };
  }
  function rememberTemplate(result, descriptor, headers, init, version) {
    if (descriptor.source !== "page" || !result.bindingId || !result.variantId || version !== runtimeGeneration) return;
    if (result.invalidateRuntime) {
      const origin = new URL(descriptor.url).origin;
      invalidateRuntime(origin);
      if (descriptor.identityHash) currentIdentity.set(origin, descriptor.identityHash);
      const tenant = ["x-tenant-id", "x-tenant", "tenant-id", "x-org-id", "x-organization-id", "x-account-id"].filter((name) => headers.has(name)).map((name) => `${name}:${headers.get(name)}`).join("\n");
      if (tenant) currentTenant.set(origin, tenant);
    }
    const scope = descriptor.identityHash ?? "";
    if (scope && currentIdentity.get(new URL(descriptor.url).origin) !== scope) return;
    const key = `${result.bindingId}:${result.variantId}`;
    templates.delete(key);
    templates.set(key, {
      descriptor,
      headers: new Headers(headers),
      init: { ...init, headers: new Headers(headers), signal: void 0 },
      scope,
      bindingId: result.bindingId,
      variantId: result.variantId,
      canReplay: Boolean(result.canReplay) && !descriptor.unsupportedReason,
      reason: descriptor.unsupportedReason ?? result.replayReason,
      updatedAt: Date.now()
    });
    let retainedBytes = [...templates.values()].reduce((sum, item) => sum + (item.descriptor.body?.length ?? 0) * 2, 0);
    while (templates.size > 200 || retainedBytes > 16 * MAX_BODY_BYTES) {
      const oldest = templates.keys().next().value;
      retainedBytes -= (templates.get(oldest).descriptor.body?.length ?? 0) * 2;
      templates.delete(oldest);
    }
  }
  async function readBounded(stream, limit = MAX_BODY_BYTES, timeoutMs = 3e4) {
    if (!stream) return "";
    const reader = stream.getReader();
    const chunks = [];
    let length = 0;
    let timer;
    const timedOut = new Promise((_, reject) => {
      timer = setTimeout(() => {
        void reader.cancel().catch(() => void 0);
        reject(new Error("\u6B63\u6587\u8BFB\u53D6\u8D85\u65F6"));
      }, timeoutMs);
    });
    try {
      while (true) {
        const { value, done } = await Promise.race([reader.read(), timedOut]);
        if (done) break;
        length += value.byteLength;
        if (length > limit) {
          void reader.cancel().catch(() => void 0);
          throw new Error("\u54CD\u5E94\u6216\u8BF7\u6C42\u6B63\u6587\u8D85\u8FC7 1 MiB");
        }
        chunks.push(value);
      }
      const combined = new Uint8Array(length);
      let offset = 0;
      for (const chunk of chunks) {
        combined.set(chunk, offset);
        offset += chunk.byteLength;
      }
      return new TextDecoder().decode(combined);
    } finally {
      clearTimeout(timer);
    }
  }
  async function completeResponse(result, response, startedAt) {
    if ([401, 403].includes(response.status)) invalidateRuntime(response.url ? new URL(response.url).origin : void 0);
    if (!result.ticket) return { saved: false, success: response.ok, reason: result.reason };
    const completion = {
      ticket: result.ticket,
      status: response.status,
      statusText: response.statusText,
      headers: safeHeaders(response.headers),
      durationMs: Date.now() - startedAt,
      redirected: response.redirected,
      responseType: response.type
    };
    const contentType = response.headers.get("content-type") ?? "";
    if (response.redirected || !/\bjson\b/i.test(contentType) || response.type === "opaque" || [204, 206].includes(response.status)) completion.unsupportedReason = "\u4EC5\u5F55\u5236\u5B8C\u6574\u3001\u975E\u91CD\u5B9A\u5411\u7684 JSON \u54CD\u5E94";
    else if (Number(response.headers.get("content-length")) > MAX_BODY_BYTES) completion.unsupportedReason = "\u54CD\u5E94\u6B63\u6587\u8D85\u8FC7 1 MiB";
    else {
      try {
        completion.bodyText = await readBounded(response.clone().body);
      } catch (error) {
        completion.unsupportedReason = error instanceof Error ? error.message : "\u65E0\u6CD5\u8BFB\u53D6\u54CD\u5E94\u526F\u672C";
      }
    }
    const completed = await bridge("COMPLETE", completion);
    if (completed.invalidateRuntime) invalidateRuntime(response.url ? new URL(response.url).origin : void 0);
    return completed;
  }
  function completeFailure(result, startedAt, error) {
    if (!result?.ticket) return;
    const name = error instanceof Error ? error.name : "Error";
    void bridge("COMPLETE", { ticket: result.ticket, status: 0, statusText: "", headers: {}, durationMs: Date.now() - startedAt, error: name === "AbortError" ? "\u8BF7\u6C42\u5DF2\u53D6\u6D88" : name === "TimeoutError" ? "\u8BF7\u6C42\u8D85\u65F6" : "\u7F51\u7EDC\u8BF7\u6C42\u5931\u8D25" }).catch(() => void 0);
  }
  async function manual(bindingId, variantId) {
    const candidates = [...templates.values()].filter((template2) => template2.bindingId === bindingId && (!variantId || template2.variantId === variantId)).sort((a, b) => b.updatedAt - a.updatedAt);
    const template = candidates[0];
    if (!template || !template.canReplay) throw new Error(template?.reason ?? "\u8BF7\u5148\u4ECE\u5F53\u524D\u9875\u9762\u89E6\u53D1\u4E00\u6B21\u771F\u5B9E\u8BF7\u6C42");
    const origin = new URL(template.descriptor.url).origin;
    if (template.scope && currentIdentity.get(origin) !== template.scope) throw new Error("\u8EAB\u4EFD\u5DF2\u53D8\u5316\uFF0C\u8BF7\u4ECE\u9875\u9762\u91CD\u65B0\u89E6\u53D1\u8BF7\u6C42");
    const cookieIdentityHash = await cookieIdentityFor(template.descriptor.url, template.descriptor.credentials);
    if (cookieIdentityHash !== template.descriptor.cookieIdentityHash) {
      invalidateRuntime(origin);
      throw new Error("\u767B\u5F55 Cookie \u5DF2\u53D8\u5316\uFF0C\u8BF7\u4ECE\u9875\u9762\u91CD\u65B0\u89E6\u53D1\u8BF7\u6C42");
    }
    const startedAt = Date.now();
    const version = runtimeVersion();
    const descriptor = { ...template.descriptor, cookieIdentityHash, requestId: requestId(), source: "manual", startedAt };
    let result;
    try {
      result = await bridge("PREPARE", descriptor);
    } catch {
      throw new Error("\u6269\u5C55\u8FDE\u63A5\u5931\u8D25\uFF0C\u672A\u53D1\u9001\u91CD\u65B0\u8BF7\u6C42");
    }
    if (result.invalidateRuntime || version !== runtimeVersion()) {
      invalidateRuntime(origin);
      completeFailure(result, startedAt, new DOMException("Context changed", "AbortError"));
      throw new Error("\u8EAB\u4EFD\u6216\u914D\u7F6E\u5DF2\u53D8\u5316\uFF0C\u8BF7\u5148\u4ECE\u9875\u9762\u91CD\u65B0\u89E6\u53D1\u8BF7\u6C42");
    }
    if (!result.canReplay || result.bindingId !== bindingId) {
      completeFailure(result, startedAt, new DOMException("Replay disabled", "AbortError"));
      throw new Error(result.replayReason ?? "\u5F53\u524D\u89C4\u5219\u4E0D\u5141\u8BB8\u91CD\u65B0\u8BF7\u6C42");
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new DOMException("Timed out", "TimeoutError")), 3e4);
    try {
      const response = await nativeFetch(template.descriptor.url, { ...template.init, headers: template.headers, signal: controller.signal, cache: descriptor.method === "GET" ? "no-store" : template.init.cache });
      const completed = await completeResponse(result, response, startedAt);
      return { ...completed, pageUrl: descriptor.pageUrl, cacheAllowed: result.ticket?.cacheAllowed };
    } catch (error) {
      completeFailure(result, startedAt, error);
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }
  function installRuntimeCommands() {
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== location.origin) return;
      const message = event.data;
      if (message?.channel !== CHANNEL || message.direction !== "command" || typeof message.id !== "string" || message.id.length > 100) return;
      void (async () => {
        let data;
        if (message.type === "INVALIDATE_RUNTIME") {
          invalidateRuntime();
          data = true;
        } else if (message.type === "RUNTIME_LIST") {
          data = [...templates.values()].filter((value) => !message.payload?.bindingId || value.bindingId === message.payload.bindingId).map(({ bindingId, variantId, canReplay, reason, updatedAt }) => ({ bindingId, variantId, canReplay, reason, updatedAt }));
        } else if (message.type === "MANUAL" && typeof message.payload?.bindingId === "string") data = await manual(message.payload.bindingId, message.payload.variantId);
        else return;
        window.postMessage({ channel: CHANNEL, direction: "command-result", id: message.id, ok: true, data }, location.origin);
      })().catch((error) => window.postMessage({ channel: CHANNEL, direction: "command-result", id: message.id, ok: false, error: error instanceof Error ? error.message : "\u64CD\u4F5C\u5931\u8D25" }, location.origin));
    });
  }

  // src/content/fetch-interceptor.ts
  function directFetch(input, init, reason) {
    const startedAt = Date.now(), pageUrl = location.href;
    const network = nativeFetch(input, init);
    try {
      const original = input instanceof Request ? input : void 0;
      const url = original?.url ?? new URL(String(input), location.href).href;
      const origin = new URL(url).origin;
      const preparing = descriptorFor(url, init?.method ?? original?.method ?? "GET", new Headers(init?.headers ?? original?.headers), void 0, init?.credentials ?? original?.credentials ?? "same-origin", pageUrl, startedAt, "page", reason).then((descriptor) => bridge("PREPARE", descriptor)).then((result) => {
        if (result.invalidateRuntime) invalidateRuntime(origin);
        return result;
      }).catch(() => void 0);
      void network.then((response) => {
        if ([401, 403].includes(response.status)) invalidateRuntime(origin);
        const completion = { status: response.status, statusText: response.statusText, headers: safeHeaders(response.headers), durationMs: Date.now() - startedAt, redirected: response.redirected, responseType: response.type, unsupportedReason: reason };
        return preparing.then(async (prepared) => {
          if (!prepared?.ticket) return;
          const completed = await bridge("COMPLETE", { ...completion, ticket: prepared.ticket });
          if (completed.invalidateRuntime) invalidateRuntime(origin);
        });
      }, (error) => preparing.then((prepared) => completeFailure(prepared, startedAt, error))).catch(() => void 0);
    } catch {
    }
    return network;
  }
  function abortAwareResponse(response, signal) {
    for (const method of ["arrayBuffer", "blob", "formData", "json", "text", "bytes"]) {
      const original = response[method];
      if (typeof original !== "function") continue;
      Object.defineProperty(response, method, { configurable: true, writable: true, value: function() {
        return Reflect.apply(original, this, []).catch((error) => {
          if (this === response && signal.aborted && error instanceof TypeError) throw new DOMException("The operation was aborted", "AbortError");
          throw error;
        });
      } });
    }
    const clone = response.clone;
    Object.defineProperty(response, "clone", { configurable: true, writable: true, value: function() {
      const cloned = Reflect.apply(clone, this, []);
      return this === response ? abortAwareResponse(cloned, signal) : cloned;
    } });
    return response;
  }
  function replayResponse(entry, signal) {
    let emitted = false;
    let onAbort;
    const bytes = new TextEncoder().encode(entry.bodyText);
    const body = new ReadableStream({
      start(controller) {
        onAbort = () => controller.error(new DOMException("The operation was aborted", "AbortError"));
        if (signal.aborted) onAbort();
        else signal.addEventListener("abort", onAbort, { once: true });
      },
      pull(controller) {
        if (!emitted && bytes.byteLength) {
          emitted = true;
          controller.enqueue(bytes);
        } else {
          signal.removeEventListener("abort", onAbort);
          controller.close();
        }
      },
      cancel() {
        signal.removeEventListener("abort", onAbort);
      }
    });
    return abortAwareResponse(new Response(body, { status: entry.status, statusText: entry.statusText, headers: entry.headers }), signal);
  }
  function installFetchInterceptor() {
    window.fetch = async function fetch(input, init) {
      if (input instanceof Request && input.body && init?.body == null) return directFetch(input, init, "Request \u6D41\u5F0F\u6B63\u6587\u4FDD\u6301\u76F4\u901A");
      if (init?.body != null && typeof init.body !== "string") return directFetch(input, init, "\u975E\u5B57\u7B26\u4E32\u8BF7\u6C42\u4F53\u4FDD\u6301\u76F4\u901A");
      const request = new Request(input, init);
      if (request.signal.aborted) throw request.signal.reason;
      if (!["http:", "https:"].includes(new URL(request.url).protocol)) return nativeFetch(request);
      const startedAt = Date.now();
      const pageUrl = location.href;
      let body;
      let unsupportedReason;
      if (request.body) {
        if (!/\bjson\b/i.test(request.headers.get("content-type") ?? "")) return directFetch(request, void 0, "\u4EC5\u652F\u6301 JSON \u8BF7\u6C42\u4F53");
        try {
          body = await readBounded(request.clone().body, MAX_BODY_BYTES, 100);
        } catch {
          return directFetch(request, void 0, "\u6B63\u6587\u8FC7\u5927\u6216\u65E0\u6CD5\u5B89\u5168\u590D\u5236\uFF0C\u4FDD\u6301\u76F4\u901A");
        }
        try {
          JSON.parse(body);
        } catch {
          unsupportedReason = "\u4EC5\u652F\u6301 JSON \u8BF7\u6C42\u4F53";
        }
      }
      if (request.mode === "no-cors") return directFetch(request, void 0, "no-cors \u8BF7\u6C42\u4FDD\u6301\u76F4\u901A");
      let prepared;
      try {
        const descriptor = await descriptorFor(request.url, request.method, request.headers, body, request.credentials, pageUrl, startedAt, "page", unsupportedReason);
        const version = runtimeVersion();
        prepared = await bridge("PREPARE", descriptor, request.signal);
        const replayInit = {
          method: request.method,
          body,
          headers: new Headers(request.headers),
          credentials: request.credentials,
          mode: request.mode,
          cache: request.cache,
          redirect: request.redirect,
          referrer: request.referrer,
          referrerPolicy: request.referrerPolicy,
          integrity: request.integrity
        };
        rememberTemplate(prepared, descriptor, request.headers, replayInit, version);
        if (request.signal.aborted) throw request.signal.reason;
        if (prepared.action === "hit" && prepared.entry) {
          return replayResponse(prepared.entry, request.signal);
        }
      } catch (error) {
        if (request.signal.aborted) {
          completeFailure(prepared, startedAt, error);
          throw request.signal.reason;
        }
      }
      try {
        const response = await nativeFetch(request);
        if (prepared) void completeResponse(prepared, response, startedAt).catch(() => void 0);
        return response;
      } catch (error) {
        completeFailure(prepared, startedAt, error);
        throw error;
      }
    };
  }

  // src/content/xhr-interceptor.ts
  var NativeXHR = window.XMLHttpRequest;
  var eventNames = ["readystatechange", "loadstart", "progress", "abort", "error", "load", "timeout", "loadend"];
  var ReplayXMLHttpRequest = class extends EventTarget {
    static UNSENT = 0;
    static OPENED = 1;
    static HEADERS_RECEIVED = 2;
    static LOADING = 3;
    static DONE = 4;
    UNSENT = 0;
    OPENED = 1;
    HEADERS_RECEIVED = 2;
    LOADING = 3;
    DONE = 4;
    #native = new NativeXHR();
    #mode = "idle";
    #sent = false;
    #asynchronous = true;
    #method = "GET";
    #url = "";
    #pageUrl = "";
    #headers = new Headers();
    #responseType = "";
    #timeout = 0;
    #state = 0;
    #entry;
    #text = "";
    #parsed;
    #parsedText;
    #token = 0;
    #timer;
    #prepared;
    #directPreparation;
    #directReason;
    #startedAt = 0;
    #unsupported = false;
    #uploadListeners = false;
    #loadStarted = false;
    #handlers = /* @__PURE__ */ new Map();
    constructor() {
      super();
      for (const type of eventNames) this.#native.addEventListener(type, (event) => {
        if (this.#mode !== "native" && !(this.#mode === "idle" && type === "readystatechange")) return;
        if (type === "loadstart" && this.#loadStarted) return;
        if (type === "loadstart") this.#loadStarted = true;
        if (type === "readystatechange" && this.#native.readyState === 4) {
          this.#sent = false;
          this.#capture();
        }
        this.#emit(type, event instanceof ProgressEvent ? event : void 0);
      });
      const upload = this.#native.upload;
      const add = upload.addEventListener;
      upload.addEventListener = ((...args) => {
        this.#uploadListeners = true;
        return Reflect.apply(add, upload, args);
      });
    }
    get [Symbol.toStringTag]() {
      return "XMLHttpRequest";
    }
    get readyState() {
      return this.#mode === "synthetic" ? this.#state : this.#native.readyState;
    }
    get status() {
      return this.#mode === "synthetic" ? this.#state >= 2 ? this.#entry?.status ?? 0 : 0 : this.#native.status;
    }
    get statusText() {
      return this.#mode === "synthetic" ? this.#state >= 2 ? this.#entry?.statusText ?? "" : "" : this.#native.statusText;
    }
    get responseURL() {
      return this.#mode === "synthetic" ? this.#state >= 2 && this.#entry ? this.#url : "" : this.#native.responseURL;
    }
    get responseType() {
      return this.#responseType;
    }
    set responseType(value) {
      if (this.#mode === "synthetic" && this.#state >= 3) throw new DOMException("The response is already loading", "InvalidStateError");
      this.#native.responseType = value === "json" ? "text" : value;
      this.#responseType = value;
    }
    get responseText() {
      if (this.#responseType !== "" && this.#responseType !== "text") throw new DOMException("responseText is only available for text responses", "InvalidStateError");
      return this.#mode === "synthetic" ? this.#state >= 3 ? this.#text : "" : this.#native.responseText;
    }
    get response() {
      if (this.#responseType === "json") {
        if (this.readyState !== 4) return null;
        const text = this.#mode === "synthetic" ? this.#text : this.#native.responseText;
        if (this.#parsedText !== text) {
          this.#parsedText = text;
          try {
            this.#parsed = JSON.parse(text);
          } catch {
            this.#parsed = null;
          }
        }
        return this.#parsed ?? null;
      }
      if (this.#mode === "synthetic") {
        if (["arraybuffer", "blob", "document"].includes(this.#responseType)) {
          if (this.#state !== 4) return null;
          if (this.#responseType === "arraybuffer") return new TextEncoder().encode(this.#text).buffer;
          if (this.#responseType === "blob") return new Blob([this.#text], { type: this.getResponseHeader("content-type") ?? "" });
          return null;
        }
        return this.#state >= 3 ? this.#text : "";
      }
      return this.#native.response;
    }
    get responseXML() {
      if (this.#responseType !== "" && this.#responseType !== "document") throw new DOMException("responseXML is unavailable", "InvalidStateError");
      return this.#mode === "synthetic" ? null : this.#native.responseXML;
    }
    get timeout() {
      return this.#timeout;
    }
    set timeout(value) {
      this.#native.timeout = value;
      this.#timeout = this.#native.timeout;
      if (this.#mode === "preparing" && this.#sent) this.#armTimeout();
    }
    get withCredentials() {
      return this.#native.withCredentials;
    }
    set withCredentials(value) {
      if (this.#sent) throw new DOMException("The request has already been sent", "InvalidStateError");
      this.#native.withCredentials = value;
    }
    get upload() {
      return this.#native.upload;
    }
    open(method, url, async = true, username, password) {
      this.#token++;
      clearTimeout(this.#timer);
      this.#mode = "idle";
      this.#sent = false;
      this.#entry = void 0;
      this.#text = "";
      this.#parsedText = void 0;
      this.#headers = new Headers();
      this.#prepared = void 0;
      this.#directPreparation = void 0;
      this.#directReason = void 0;
      this.#loadStarted = false;
      this.#method = String(method).toUpperCase();
      this.#url = new URL(String(url), location.href).href;
      this.#asynchronous = Boolean(async);
      this.#unsupported = username != null || password != null;
      Reflect.apply(this.#native.open, this.#native, Array.from(arguments));
    }
    setRequestHeader(name, value) {
      if (this.#sent) throw new DOMException("The request has already been sent", "InvalidStateError");
      this.#native.setRequestHeader(name, value);
      this.#headers.append(name, value);
    }
    overrideMimeType(mime) {
      this.#native.overrideMimeType(mime);
      this.#unsupported = true;
    }
    getResponseHeader(name) {
      if (this.#mode !== "synthetic") return this.#native.getResponseHeader(name);
      if (this.#state < 2 || !this.#entry || /^(set-cookie|set-cookie2)$/i.test(name)) return null;
      return new Headers(this.#entry.headers).get(name);
    }
    getAllResponseHeaders() {
      if (this.#mode !== "synthetic") return this.#native.getAllResponseHeaders();
      if (this.#state < 2 || !this.#entry) return "";
      return Array.from(new Headers(this.#entry.headers)).filter(([name]) => !/^set-cookie2?$/i.test(name)).map(([name, value]) => `${name}: ${value}\r
`).join("");
    }
    send(body) {
      if (this.readyState !== 1 || this.#sent) throw new DOMException("The request is not opened or was already sent", "InvalidStateError");
      const bodyIgnored = ["GET", "HEAD"].includes(this.#method);
      const rawBody = bodyIgnored ? void 0 : body ?? void 0;
      const uploadUsed = this.#uploadListeners || ["onloadstart", "onprogress", "onabort", "onerror", "onload", "ontimeout", "onloadend"].some((key) => Boolean(this.#native.upload[key]));
      let jsonBody = true;
      if (rawBody !== void 0) {
        if (typeof rawBody !== "string" || !/\bjson\b/i.test(this.#headers.get("content-type") ?? "") || new TextEncoder().encode(rawBody).byteLength > MAX_BODY_BYTES) jsonBody = false;
        else {
          try {
            JSON.parse(rawBody);
          } catch {
            jsonBody = false;
          }
        }
      }
      this.#sent = true;
      this.#startedAt = Date.now();
      this.#pageUrl = location.href;
      if (!this.#asynchronous || this.#unsupported || uploadUsed || !jsonBody || !["", "text", "json"].includes(this.#responseType) || !/^https?:/.test(this.#url)) {
        this.#mode = "native";
        if (/^https?:/.test(this.#url)) {
          this.#directReason = "\u540C\u6B65\u3001\u4E0A\u4F20\u3001\u4E8C\u8FDB\u5236\u6216\u4E0D\u652F\u6301\u7684\u8BF7\u6C42\u4F53\u4FDD\u6301\u76F4\u901A";
          const origin = new URL(this.#url).origin;
          this.#directPreparation = descriptorFor(this.#url, this.#method, this.#headers, void 0, this.withCredentials ? "include" : "same-origin", this.#pageUrl, this.#startedAt, "page", this.#directReason).then((descriptor) => bridge("PREPARE", descriptor)).then((result) => {
            if (result.invalidateRuntime) invalidateRuntime(origin);
            return result;
          }).catch(() => void 0);
        }
        try {
          this.#native.send(body);
        } catch (error) {
          this.#sent = false;
          const pending = this.#directPreparation, startedAt = this.#startedAt;
          this.#directPreparation = void 0;
          if (pending) void pending.then((result) => completeFailure(result, startedAt, error));
          throw error;
        }
        return;
      }
      this.#mode = "preparing";
      const token = ++this.#token;
      this.#armTimeout();
      this.#loadStarted = true;
      this.#emit("loadstart");
      if (!this.#sent || token !== this.#token) return;
      void (async () => {
        const credentials = this.#native.withCredentials ? "include" : "same-origin";
        try {
          const descriptor = await descriptorFor(this.#url, this.#method, this.#headers, rawBody, credentials, this.#pageUrl, this.#startedAt);
          const version = runtimeVersion();
          if (token !== this.#token || !this.#sent) return;
          const prepared = await bridge("PREPARE", descriptor);
          if (token !== this.#token || !this.#sent) {
            completeFailure(prepared, this.#startedAt, new DOMException("Aborted", "AbortError"));
            return;
          }
          this.#prepared = prepared;
          rememberTemplate(prepared, descriptor, this.#headers, { method: this.#method, headers: this.#headers, body: rawBody, credentials }, version);
          if (prepared.action === "hit" && prepared.entry && !this.#unsupported && ["", "text", "json"].includes(this.#responseType)) {
            this.#deliver(prepared.entry, token);
            return;
          }
        } catch {
        }
        if (token !== this.#token || !this.#sent) return;
        this.#startNative(body);
      })();
    }
    abort() {
      if (this.#mode === "preparing") {
        this.#fail("abort");
        this.#state = 0;
        return;
      }
      if (this.#mode === "synthetic" && this.#sent) {
        this.#fail("abort");
        this.#state = 0;
        return;
      }
      this.#token++;
      this.#native.abort();
      if (this.#mode === "synthetic") {
        this.#state = 0;
        this.#entry = void 0;
        this.#text = "";
      }
    }
    #startNative(body) {
      clearTimeout(this.#timer);
      if (this.#timeout > 0) {
        const remaining = this.#timeout - (Date.now() - this.#startedAt);
        if (remaining <= 0) {
          this.#fail("timeout");
          return;
        }
        this.#native.timeout = remaining;
      }
      this.#mode = "native";
      try {
        this.#native.send(body);
      } catch (error) {
        completeFailure(this.#prepared, this.#startedAt, error);
        this.#fail("error");
      }
    }
    #armTimeout() {
      clearTimeout(this.#timer);
      if (this.#timeout > 0) this.#timer = setTimeout(() => this.#fail("timeout"), Math.max(0, this.#timeout - (Date.now() - this.#startedAt)));
    }
    #deliver(entry, token) {
      clearTimeout(this.#timer);
      this.#mode = "synthetic";
      this.#entry = entry;
      const active = () => token === this.#token && this.#sent;
      this.#state = 2;
      this.#emit("readystatechange");
      if (!active()) return;
      this.#text = entry.bodyText;
      this.#state = 3;
      this.#emit("readystatechange");
      if (!active()) return;
      const size = new TextEncoder().encode(entry.bodyText).byteLength;
      const progress = new ProgressEvent("progress", { lengthComputable: true, loaded: size, total: size });
      this.#emit("progress", progress);
      if (!active()) return;
      this.#state = 4;
      this.#emit("readystatechange");
      if (!active()) return;
      this.#sent = false;
      this.#emit("load", progress);
      this.#emit("loadend", progress);
    }
    #fail(type) {
      if (!this.#sent) return;
      clearTimeout(this.#timer);
      this.#token++;
      this.#sent = false;
      this.#mode = "synthetic";
      this.#entry = void 0;
      this.#text = "";
      this.#state = 4;
      this.#native.abort();
      completeFailure(this.#prepared, this.#startedAt, new DOMException(type, type === "abort" ? "AbortError" : type === "timeout" ? "TimeoutError" : "NetworkError"));
      this.#emit("readystatechange");
      this.#emit(type);
      this.#emit("loadend");
    }
    #emit(type, progress) {
      this.dispatchEvent(type === "readystatechange" ? new Event(type) : new ProgressEvent(type, { lengthComputable: progress?.lengthComputable ?? false, loaded: progress?.loaded ?? 0, total: progress?.total ?? 0 }));
    }
    #capture() {
      const prepared = this.#prepared;
      const directPreparation = this.#directPreparation;
      this.#prepared = void 0;
      this.#directPreparation = void 0;
      const status = this.#native.status;
      if ([401, 403].includes(status)) invalidateRuntime(new URL(this.#url).origin);
      if (!prepared?.ticket && !directPreparation) return;
      const startedAt = this.#startedAt;
      if (!status) {
        completeFailure(prepared, startedAt, new Error("Network error"));
        if (directPreparation) void directPreparation.then((result) => completeFailure(result, startedAt, new Error("Network error")));
        return;
      }
      const headers = new Headers();
      for (const line of this.#native.getAllResponseHeaders().trim().split(/[\r\n]+/)) {
        const separator = line.indexOf(":");
        if (separator > 0) headers.append(line.slice(0, separator).trim(), line.slice(separator + 1).trim());
      }
      const completion = { status, statusText: this.#native.statusText, headers: safeHeaders(headers), durationMs: Date.now() - startedAt, redirected: this.#native.responseURL !== this.#url.split("#")[0] };
      if (this.#directReason) completion.unsupportedReason = this.#directReason;
      else if (!/\bjson\b/i.test(headers.get("content-type") ?? "") || [204, 206].includes(status) || !["", "text", "json"].includes(this.#responseType)) completion.unsupportedReason = "\u4EC5\u5F55\u5236\u5B8C\u6574 JSON \u6587\u672C\u54CD\u5E94";
      else {
        const text = this.#native.responseText;
        if (new TextEncoder().encode(text).byteLength > MAX_BODY_BYTES) completion.unsupportedReason = "\u54CD\u5E94\u6B63\u6587\u8D85\u8FC7 1 MiB";
        else completion.bodyText = text;
      }
      const origin = new URL(this.#url).origin;
      const record = async (result) => {
        if (!result?.ticket) return;
        const completed = await bridge("COMPLETE", { ...completion, ticket: result.ticket });
        if (completed.invalidateRuntime) invalidateRuntime(origin);
      };
      void (directPreparation ? directPreparation.then(record) : record(prepared)).catch(() => void 0);
    }
    getHandler(type) {
      return this.#handlers.get(type) ?? null;
    }
    setHandler(type, listener) {
      const previous = this.#handlers.get(type);
      if (previous) this.removeEventListener(type, previous);
      if (typeof listener === "function") {
        this.#handlers.set(type, listener);
        this.addEventListener(type, listener);
      } else this.#handlers.delete(type);
    }
  };
  for (const type of eventNames) Object.defineProperty(ReplayXMLHttpRequest.prototype, `on${type}`, {
    configurable: true,
    enumerable: true,
    get() {
      return this.getHandler(type);
    },
    set(listener) {
      this.setHandler(type, listener);
    }
  });
  function installXhrInterceptor() {
    window.XMLHttpRequest = ReplayXMLHttpRequest;
  }

  // src/content/route-tracker.ts
  function installRouteTracker() {
    let previous = location.href;
    const notify = () => {
      if (previous === location.href) return;
      previous = location.href;
      window.postMessage({ channel: CHANNEL, direction: "route", pageUrl: previous }, location.origin);
    };
    for (const method of ["pushState", "replaceState"]) {
      const original = history[method];
      history[method] = function(...args) {
        const result = Reflect.apply(original, this, args);
        notify();
        return result;
      };
    }
    window.addEventListener("popstate", notify);
    window.addEventListener("hashchange", notify);
  }

  // src/content/main.ts
  var marker = /* @__PURE__ */ Symbol.for("API_CACHE_REPLAY_MAIN_V1");
  var runtime = window;
  if (window === window.top && !runtime[marker]) {
    runtime[marker] = true;
    installRuntimeCommands();
    installRouteTracker();
    installFetchInterceptor();
    installXhrInterceptor();
  }
})();
//# sourceMappingURL=main.js.map
