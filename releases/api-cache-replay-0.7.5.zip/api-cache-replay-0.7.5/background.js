// src/shared/types.ts
var MAX_BODY_BYTES = 1024 * 1024;

// src/shared/normalize.ts
var SENSITIVE = /authorization|cookie|password|passwd|secret|token|csrf|xsrf|api[-_]?key|signature/i;
var isSensitiveKey = (key) => SENSITIVE.test(key);
function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value) ?? "undefined";
}
function normalizeQuery(params, ignored = []) {
  const keys = [...new Set(params.keys())].filter((key) => !ignored.includes(key)).sort();
  return stableStringify(keys.map((key) => [key, params.getAll(key)]));
}
function pointerParts(pointer) {
  if (!pointer.startsWith("/") || /~(?![01])/u.test(pointer)) throw new Error("Body \u5B57\u6BB5\u5FC5\u987B\u4F7F\u7528\u6709\u6548 JSON Pointer\uFF0C\u4F8B\u5982 /pagination/page");
  return pointer.slice(1).split("/").map((part) => part.replace(/~1/g, "/").replace(/~0/g, "~"));
}
function valueAtPointer(value, pointer) {
  if (pointer === "") return value;
  let result = value;
  for (const part of pointerParts(pointer)) {
    if (!result || typeof result !== "object" || !Object.hasOwn(result, part)) return void 0;
    result = result[part];
  }
  return result;
}
function normalizeBody(body, ignored = []) {
  if (body === void 0) return "absent";
  const parsed = JSON.parse(body);
  for (const pointer of ignored) {
    const parts = pointerParts(pointer);
    let parent = parsed;
    for (const key of parts.slice(0, -1)) {
      if (!parent || typeof parent !== "object" || !Object.hasOwn(parent, key)) {
        parent = void 0;
        break;
      }
      parent = parent[key];
    }
    if (parent && typeof parent === "object") {
      const last = parts.at(-1);
      if (Array.isArray(parent)) {
        if (/^(0|[1-9]\d*)$/.test(last) && Number(last) < parent.length && Object.hasOwn(parent, last)) {
          parent[Number(last)] = { "$apiCacheReplayIgnored": true };
        }
      } else delete parent[last];
    }
  }
  return `json:${stableStringify(parsed)}`;
}
function pageRouteKey(pageUrl, site) {
  const page = new URL(pageUrl);
  const route = site.routeMode === "hash" ? new URL(page.hash.slice(1) || "/", page.origin) : page;
  return `${site.routeMode}:${route.pathname}?${normalizeQuery(new URLSearchParams([...route.searchParams].filter(([key]) => site.pageIdentityQueryKeys.includes(key))))}`;
}
function endpointInScope(url, site) {
  if (!["http:", "https:"].includes(url.protocol)) return false;
  return site.apiScopeMode === "all" || site.apiScopes.some((scope) => url.origin === scope.origin && url.pathname.startsWith(scope.pathPrefix));
}
function isAuthPath(pathname, patterns) {
  return patterns.some((pattern) => {
    if (pattern.startsWith("/")) return pathname === pattern || pathname.startsWith(pattern.endsWith("/") ? pattern : `${pattern}/`);
    return pathname.toLowerCase().split("/").filter(Boolean).at(-1) === pattern.toLowerCase();
  });
}
function normalizedRequestParts(url, body, headers, rule) {
  const target = new URL(url);
  const lowerHeaders = Object.fromEntries(Object.entries(headers).map(([key, value]) => [key.toLowerCase(), value]));
  const vary = rule.varyHeaders.map((key) => key.toLowerCase()).sort().map((key) => [key, lowerHeaders[key] ?? null]);
  const normalizedBody = normalizeBody(body, rule.forceCache ? [] : rule.ignoreBodyPointers);
  const query = rule.forceCache ? "forced-query" : normalizeQuery(target.searchParams, rule.ignoreQueryKeys);
  const matchedBody = rule.forceCache ? "forced-body" : normalizedBody;
  return { normalized: stableStringify([rule.method, target.origin, target.pathname, query, matchedBody, vary]), query, body: matchedBody, headers: stableStringify(vary) };
}
function redactUrl(url) {
  const target = new URL(url);
  target.username = "";
  target.password = "";
  target.hash = "";
  for (const key of new Set(target.searchParams.keys())) if (isSensitiveKey(key)) target.searchParams.set(key, "[REDACTED]");
  return target.href.slice(0, 8192);
}
function redactBody(body) {
  if (body === void 0) return void 0;
  try {
    const redact = (value) => {
      if (Array.isArray(value)) return value.map(redact);
      if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, isSensitiveKey(key) ? "[REDACTED]" : redact(child)]));
      return value;
    };
    const text = JSON.stringify(redact(JSON.parse(body)));
    return text.length > 8192 ? "[\u8BF7\u6C42\u4F53\u8FC7\u957F\uFF0C\u672A\u6301\u4E45\u5316]" : text;
  } catch {
    return "[\u4E0D\u652F\u6301\u7684\u8BF7\u6C42\u4F53\uFF0C\u672A\u6301\u4E45\u5316]";
  }
}
async function digest(text) {
  const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(hash)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

// src/background/network-reason.ts
var labels = {
  MANUAL: "\u624B\u52A8\u91CD\u65B0\u8BF7\u6C42",
  EXPIRED: "\u7F13\u5B58\u5DF2\u8FC7\u671F",
  CLEARED: "\u7F13\u5B58\u5DF2\u6E05\u7A7A",
  RULES_CHANGED: "\u7F13\u5B58\u89C4\u5219\u5DF2\u4FEE\u6539",
  FORCE_MODE_CHANGED: "\u5F3A\u5236\u7F13\u5B58\u6A21\u5F0F\u5DF2\u5207\u6362",
  IDENTITY_CHANGED: "\u8EAB\u4EFD\u5206\u533A\u5DF2\u53D8\u5316",
  SESSION_CHANGED: "\u6D4F\u89C8\u5668\u4F1A\u8BDD\u5DF2\u53D8\u5316",
  FIRST_REQUEST: "\u9996\u6B21\u8BF7\u6C42",
  QUERY_CHANGED: "Query \u53C2\u6570\u5DF2\u53D8\u5316",
  BODY_CHANGED: "Body \u53C2\u6570\u5DF2\u53D8\u5316",
  PARAMETERS_CHANGED: "\u8BF7\u6C42\u53C2\u6570\u5DF2\u53D8\u5316",
  HEADERS_CHANGED: "\u5339\u914D\u8BF7\u6C42\u5934\u5DF2\u53D8\u5316",
  CREDENTIALS_CHANGED: "\u51ED\u8BC1\u53D1\u9001\u65B9\u5F0F\u5DF2\u53D8\u5316",
  NOT_RECORDED: "\u6B64\u524D\u672A\u6210\u529F\u5F55\u5236",
  IN_FLIGHT: "\u4E0A\u6B21\u8BF7\u6C42\u5C1A\u672A\u5199\u5165\u7F13\u5B58",
  EVICTED: "\u7F13\u5B58\u5DF2\u88AB\u5BB9\u91CF\u6DD8\u6C70",
  CACHE_DISABLED: "\u7F13\u5B58\u5F00\u5173\u5DF2\u5173\u95ED",
  BYPASS: "\u5F53\u524D\u8BF7\u6C42\u9700\u76F4\u901A",
  UNAVAILABLE: "\u5F53\u524D\u65E0\u53EF\u7528\u7F13\u5B58"
};
var networkReason = (code, detail) => ({ code, label: labels[code], ...detail ? { detail } : {} });
function rememberInvalidation(state, key, bindingId, code, variantId) {
  delete state.missTraces[key];
  state.missTraces[key] = { bindingId, variantId, code };
  const keys = Object.keys(state.missTraces);
  for (const expired of keys.slice(0, Math.max(0, keys.length - 6e3))) delete state.missTraces[expired];
}
function forgetVariantDiagnostics(state, variantId) {
  delete state.requestFingerprints[variantId];
  for (const [key, trace] of Object.entries(state.missTraces)) if (trace.variantId === variantId) delete state.missTraces[key];
}
function fingerprintChange(previous, current) {
  if (!previous || previous.ruleVersion !== current.ruleVersion) return;
  if (previous.credentials !== current.credentials) return networkReason("CREDENTIALS_CHANGED");
  if (previous.headers !== current.headers) return networkReason("HEADERS_CHANGED");
  if (previous.tabId === current.tabId && previous.session && current.session && previous.session !== current.session) return networkReason("SESSION_CHANGED");
  if (previous.identity !== current.identity) return networkReason("IDENTITY_CHANGED");
  const query = previous.query !== current.query, body = previous.body !== current.body;
  if (query && body) return networkReason("PARAMETERS_CHANGED", "\u5F52\u4E00\u5316\u540E\u7684 Query \u548C Body \u5747\u4E0D\u540C\u3002");
  if (query) return networkReason("QUERY_CHANGED");
  if (body) return networkReason("BODY_CHANGED");
}

// src/background/scope-discovery.ts
var MAX_SCOPE_DISCOVERIES_PER_SITE = 50;
var MAX_SCOPE_DISCOVERIES_TOTAL = 500;
var MAX_DISCOVERED_ENDPOINTS = 200;
var MAX_METHODS = 16;
var MAX_EXAMPLES = 3;
var MAX_EXAMPLE_LENGTH = 2048;
async function recordScopeDiscovery(state, site, rule, now) {
  const url = new URL(rule.apiOrigin);
  url.pathname = rule.pathname;
  if (!endpointInScope(url, site)) return;
  const pathPrefix = url.pathname.match(/^\/+[^/]+/)?.[0] ?? url.pathname;
  if (pathPrefix.length > 512) return;
  const id = await digest(stableStringify([site.id, url.origin, pathPrefix]));
  const endpointHash = await digest(stableStringify([rule.method, url.pathname]));
  const previous = state.scopeDiscoveries[id];
  const endpointHashes = previous?.endpointHashes ?? [];
  let capped = previous?.view.endpointCountCapped ?? false;
  if (!endpointHashes.includes(endpointHash)) {
    if (endpointHashes.length < MAX_DISCOVERED_ENDPOINTS) endpointHashes.push(endpointHash);
    else capped = true;
  }
  const methods = [.../* @__PURE__ */ new Set([...previous?.view.methods ?? [], rule.method])].slice(0, MAX_METHODS).sort();
  const example = url.pathname.slice(0, MAX_EXAMPLE_LENGTH);
  const examples = [.../* @__PURE__ */ new Set([...previous?.view.examples ?? [], example])].slice(0, MAX_EXAMPLES);
  state.scopeDiscoveries[id] = {
    endpointHashes,
    view: { id, siteId: site.id, origin: url.origin, pathPrefix, methods, examples, lastSeenAt: Math.max(previous?.view.lastSeenAt ?? 0, now), endpointCount: endpointHashes.length, ...capped ? { endpointCountCapped: true } : {} }
  };
  const evict = (items, maximum) => {
    for (const item of items.sort((a, b) => a.view.lastSeenAt - b.view.lastSeenAt).slice(0, Math.max(0, items.length - maximum))) delete state.scopeDiscoveries[item.view.id];
  };
  evict(Object.values(state.scopeDiscoveries).filter((item) => item.view.siteId === site.id), MAX_SCOPE_DISCOVERIES_PER_SITE);
  evict(Object.values(state.scopeDiscoveries), MAX_SCOPE_DISCOVERIES_TOTAL);
}
function scopeDiscoveryState(state, site) {
  return {
    siteId: site.id,
    mode: site.apiScopeMode ?? "custom",
    scopes: Object.values(state.scopeDiscoveries).filter((item) => item.view.siteId === site.id).map((item) => ({ ...item.view, methods: [...item.view.methods], examples: [...item.view.examples] })).sort((a, b) => b.lastSeenAt - a.lastSeenAt || a.origin.localeCompare(b.origin) || a.pathPrefix.localeCompare(b.pathPrefix))
  };
}
function clearScopeDiscoveries(state, siteId) {
  for (const [id, item] of Object.entries(state.scopeDiscoveries)) if (item.view.siteId === siteId) delete state.scopeDiscoveries[id];
}

// src/background/cache-store.ts
var TOTAL_CACHE_BYTES = 100 * 1024 * 1024;
var emptyState = () => ({ requestFingerprints: {}, fingerprintSequence: 0, missTraces: {}, schemaVersion: 2, scopeDiscoveries: {}, paused: false, sequence: 0, sites: {}, pages: {}, rules: {}, variants: {}, tickets: {}, index: {}, successfulSequences: {}, identities: {}, logs: [] });
function migrateState(state) {
  state.scopeDiscoveries ??= {};
  state.requestFingerprints ??= {};
  state.fingerprintSequence ??= 0;
  state.missTraces ??= {};
  state.successfulSequences ??= {};
  for (const [key, value] of Object.entries(state.successfulSequences)) if (typeof value === "number") delete state.successfulSequences[key];
  if (state.schemaVersion !== 1) return false;
  for (const site of Object.values(state.sites)) {
    site.apiScopeMode = "all";
    site.cacheEnabled = true;
    site.identityMode = "auto";
    site.generation++;
  }
  for (const page of Object.values(state.pages)) {
    page.cacheEnabled = true;
    page.generation++;
  }
  for (const rule of Object.values(state.rules)) {
    rule.enabled = true;
    rule.allowNoStore = true;
    if (rule.method === "POST") rule.readOnly = true;
    rule.generation++;
    rule.ruleVersion++;
  }
  for (const variant of Object.values(state.variants)) {
    delete variant.cachedAt;
    delete variant.expiresAt;
    delete variant.sizeBytes;
    variant.lastStatus = "BYPASS";
    variant.reason = "\u5DF2\u5347\u7EA7\u4E3A\u81EA\u52A8\u7F13\u5B58\uFF0C\u8BF7\u91CD\u65B0\u89E6\u53D1\u8BF7\u6C42";
    delete variant.lastError;
    delete variant.networkReason;
    delete variant.lastObservedSequence;
  }
  state.index = {};
  state.tickets = {};
  state.identities = {};
  state.successfulSequences = {};
  state.requestFingerprints = {};
  state.missTraces = {};
  state.fingerprintSequence = 0;
  state.schemaVersion = 2;
  return true;
}
function storageStats(state) {
  const stats = {
    cacheBytes: 0,
    previewBytes: 0,
    totalBytes: 0,
    limitBytes: TOTAL_CACHE_BYTES,
    cacheCount: 0,
    previewCount: 0,
    requestRecordCount: Object.keys(state.variants).length,
    pendingCount: Object.keys(state.tickets).length
  };
  for (const entry of Object.values(state.index)) {
    if (entry.preview) {
      stats.previewBytes += entry.sizeBytes;
      stats.previewCount++;
    } else {
      stats.cacheBytes += entry.sizeBytes;
      stats.cacheCount++;
    }
  }
  stats.totalBytes = stats.cacheBytes + stats.previewBytes;
  return stats;
}
function sessionFor(state, changes, read) {
  return {
    state,
    async get(key) {
      return changes.has(key) ? changes.get(key) ?? void 0 : read(key);
    },
    put(key, entry, preview = false) {
      changes.set(key, entry);
      state.index[key] = { key, bindingId: entry.bindingId, variantId: entry.variantId, sizeBytes: entry.sizeBytes, lastAccessedAt: entry.lastAccessedAt, preview };
    },
    delete(key) {
      changes.set(key, null);
      delete state.index[key];
    }
  };
}
function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
var IndexedDBRepository = class {
  database;
  queue = Promise.resolve();
  open() {
    return this.database ??= new Promise((resolve, reject) => {
      const request = indexedDB.open("api-cache-replay", 1);
      request.onupgradeneeded = () => {
        request.result.createObjectStore("meta");
        request.result.createObjectStore("bodies");
      };
      request.onsuccess = () => {
        request.result.onversionchange = () => {
          request.result.close();
          this.database = void 0;
        };
        resolve(request.result);
      };
      request.onerror = () => {
        this.database = void 0;
        reject(request.error);
      };
    });
  }
  run(operation) {
    const job = this.queue.then(async () => {
      const db = await this.open();
      const state = await requestResult(db.transaction("meta").objectStore("meta").get("state")) ?? emptyState();
      const resetBodies = migrateState(state);
      const changes = /* @__PURE__ */ new Map();
      const value = await operation(sessionFor(state, changes, (key) => resetBodies ? Promise.resolve(void 0) : requestResult(db.transaction("bodies").objectStore("bodies").get(key))));
      await new Promise((resolve, reject) => {
        const transaction = db.transaction(["meta", "bodies"], "readwrite");
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
        transaction.onabort = () => reject(transaction.error ?? new Error("\u6570\u636E\u5E93\u4E8B\u52A1\u53D6\u6D88"));
        transaction.objectStore("meta").put(state, "state");
        if (resetBodies) transaction.objectStore("bodies").clear();
        for (const [key, entry] of changes) {
          if (entry) transaction.objectStore("bodies").put(entry, key);
          else transaction.objectStore("bodies").delete(key);
        }
      });
      return value;
    });
    this.queue = job.catch(() => void 0);
    return job;
  }
};
function evictToBudget(session) {
  const indexes = Object.values(session.state.index);
  let total = indexes.reduce((sum, entry) => sum + entry.sizeBytes, 0);
  for (const entry of indexes.sort((a, b) => a.lastAccessedAt - b.lastAccessedAt)) {
    if (total <= TOTAL_CACHE_BYTES) break;
    if (!entry.preview) rememberInvalidation(session.state, `cache:${entry.key}`, entry.bindingId, "EVICTED", entry.variantId);
    session.delete(entry.key);
    total -= entry.sizeBytes;
    const variant = session.state.variants[entry.variantId];
    if (variant && !entry.preview) {
      delete variant.cachedAt;
      delete variant.expiresAt;
      delete variant.sizeBytes;
    }
  }
}

// src/background/core.ts
var MAX_VARIANTS = 4e3;
var MAX_RULES = 2e3;
var MAX_PAGES = 1e3;
var DEFAULT_AUTH_PATHS = ["login", "logout", "token", "refresh", "signin", "signout"];
var bytes = (value) => new TextEncoder().encode(value).byteLength;
var own = (value) => !!value && typeof value === "object" && !Array.isArray(value);
var ensure = (condition, message) => {
  if (!condition) throw new Error(message);
};
var lower = (headers) => Object.fromEntries(Object.entries(headers).map(([key, value]) => [key.toLowerCase(), value]));
var stringList = (value, max = 50) => {
  ensure(Array.isArray(value) && value.length <= max && value.every((item) => typeof item === "string" && item.length <= 256), "\u5B57\u6BB5\u5217\u8868\u65E0\u6548\u6216\u8FC7\u957F");
  return [...new Set(value)];
};
function ttlValue(value) {
  ensure(typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 365 * 24 * 36e5, "\u6709\u6548\u671F\u987B\u4E3A 0 \u81F3 365 \u5929\u7684\u6BEB\u79D2\u6570");
  return value;
}
function httpUrl(value) {
  ensure(typeof value === "string" && value.length <= 16384, "URL \u65E0\u6548\u6216\u8FC7\u957F");
  const url = new URL(value);
  ensure(["http:", "https:"].includes(url.protocol) && !url.username && !url.password, "\u4EC5\u652F\u6301\u65E0\u5185\u5D4C\u51ED\u8BC1\u7684 HTTP/HTTPS \u5730\u5740");
  ensure(!["chrome.google.com", "chromewebstore.google.com"].includes(url.hostname), "Chrome \u5546\u5E97\u9875\u9762\u4E0D\u5141\u8BB8\u6CE8\u5165\u6269\u5C55");
  return url;
}
function originPattern(origin) {
  const url = new URL(origin);
  return `${url.protocol}//${url.hostname}/*`;
}
var identityKeyFor = (siteId, sender, apiOrigin) => `${siteId}:${stableStringify([sender.tab?.id, sender.documentId ?? "unknown", apiOrigin])}`;
function clearBindings(session, ids, variantId, diagnosticCode) {
  if (diagnosticCode) {
    for (const [key, trace] of Object.entries(session.state.missTraces)) if (ids.has(trace.bindingId) && (!variantId || trace.variantId === variantId)) delete session.state.missTraces[key];
    if (!variantId) for (const id of ids) rememberInvalidation(session.state, `binding:${id}`, id, diagnosticCode);
    for (const variant of Object.values(session.state.variants)) if (ids.has(variant.bindingId) && (!variantId || variant.id === variantId)) rememberInvalidation(session.state, `variant:${variant.id}`, variant.bindingId, diagnosticCode, variant.id);
  }
  for (const index of Object.values(session.state.index)) if (ids.has(index.bindingId) && (!variantId || variantId === index.variantId)) session.delete(index.key);
  for (const variant of Object.values(session.state.variants)) if (ids.has(variant.bindingId) && (!variantId || variant.id === variantId)) {
    delete variant.cachedAt;
    delete variant.expiresAt;
    delete variant.sizeBytes;
  }
  for (const [key, watermark] of Object.entries(session.state.successfulSequences)) if (ids.has(session.state.variants[watermark.variantId]?.bindingId) && (!variantId || watermark.variantId === variantId)) delete session.state.successfulSequences[key];
}
function rulesForSite(session, siteId) {
  return Object.values(session.state.rules).filter((rule) => session.state.pages[rule.pageId]?.siteId === siteId);
}
function invalidateSite(session, site) {
  site.generation++;
  clearBindings(session, new Set(rulesForSite(session, site.id).map((rule) => rule.id)), void 0, "IDENTITY_CHANGED");
  for (const key of Object.keys(session.state.identities)) if (key.startsWith(`${site.id}:`)) delete session.state.identities[key];
}
function removeBinding(session, bindingId) {
  clearBindings(session, /* @__PURE__ */ new Set([bindingId]));
  for (const variant of Object.values(session.state.variants)) if (variant.bindingId === bindingId) {
    forgetVariantDiagnostics(session.state, variant.id);
    delete session.state.variants[variant.id];
  }
  for (const [key, trace] of Object.entries(session.state.missTraces)) if (trace.bindingId === bindingId) delete session.state.missTraces[key];
  for (const ticket of Object.values(session.state.tickets)) if (ticket.bindingId === bindingId) delete session.state.tickets[ticket.id];
  delete session.state.rules[bindingId];
}
function defaultRule(page, method, url, alias = "") {
  return { id: crypto.randomUUID(), pageId: page.id, method, apiOrigin: url.origin, pathname: url.pathname, alias, enabled: true, forceCache: false, alwaysBypass: false, readOnly: method === "GET" || method === "POST", ignoreQueryKeys: [], ignoreBodyPointers: [], varyHeaders: ["accept-language", "x-tenant-id"], allowNoStore: true, ruleVersion: 1, generation: 1, invalidateBindingIds: [] };
}
function getPage(session, site, url) {
  const routeKey = pageRouteKey(url, site);
  let page = Object.values(session.state.pages).find((item) => item.siteId === site.id && item.routeKey === routeKey);
  if (!page) {
    ensure(Object.keys(session.state.pages).length < MAX_PAGES, "\u9875\u9762\u8BB0\u5F55\u5DF2\u8FBE\u4E0A\u9650");
    page = { id: crypto.randomUUID(), siteId: site.id, routeKey, cacheEnabled: true, generation: 1 };
    session.state.pages[page.id] = page;
  }
  return page;
}
var CacheCore = class {
  constructor(repository2, environment) {
    this.repository = repository2;
    this.environment = environment;
    this.now = environment.now ?? Date.now;
  }
  repository;
  environment;
  now;
  isOptions(sender) {
    const extensionOrigin = `chrome-extension://${this.environment.extensionId}`;
    return sender.id === this.environment.extensionId && sender.url?.split(/[?#]/)[0] === `${extensionOrigin}/options.html` && (sender.origin === void 0 || sender.origin === extensionOrigin) && (sender.frameId === void 0 || sender.frameId === 0) && (!sender.tab?.url || sender.tab.url.startsWith(`${extensionOrigin}/`));
  }
  requireOptions(sender) {
    ensure(this.isOptions(sender), "\u8BE5\u64CD\u4F5C\u4EC5\u5141\u8BB8\u5728\u6269\u5C55\u8BBE\u7F6E\u9875\u6267\u884C");
  }
  async siteFor(session, sender, pageUrl) {
    ensure(sender.id === this.environment.extensionId && sender.frameId === 0 && typeof sender.tab?.id === "number", "\u4EC5\u5141\u8BB8\u5DF2\u6388\u6743\u7684\u9876\u5C42\u9875\u9762");
    const page = httpUrl(pageUrl), senderUrl = httpUrl(sender.url);
    ensure(page.origin === senderUrl.origin && (!sender.origin || sender.origin === page.origin), "\u9875\u9762\u6765\u6E90\u4E0D\u5339\u914D");
    if (sender.tab?.url) ensure(new URL(sender.tab.url).origin === page.origin, "\u6807\u7B7E\u9875\u6765\u6E90\u4E0D\u5339\u914D");
    const site = Object.values(session.state.sites).find((item) => item.origin === page.origin);
    return site && await this.environment.hasPermission(site.origin) ? site : void 0;
  }
  pageRules(session, page) {
    return Object.values(session.state.rules).filter((rule) => rule.pageId === page.id);
  }
  scopedRule(session, page, bindingId) {
    const rule = typeof bindingId === "string" ? session.state.rules[bindingId] : void 0;
    ensure(rule && rule.pageId === page.id, "\u63A5\u53E3\u7ED1\u5B9A\u4E0D\u5C5E\u4E8E\u5F53\u524D\u9875\u9762");
    return rule;
  }
  validateSite(input, old) {
    ensure(own(input), "\u7F51\u7AD9\u8BBE\u7F6E\u65E0\u6548");
    const site = input;
    const origin = httpUrl(site.origin).origin;
    ensure(site.origin === origin || site.origin === `${origin}/`, "\u7F51\u7AD9\u5730\u5740\u53EA\u586B\u5199 origin\uFF08\u534F\u8BAE\u3001\u4E3B\u673A\u548C\u7AEF\u53E3\uFF09");
    const apiScopeMode = site.apiScopeMode ?? "all";
    ensure(["all", "custom"].includes(apiScopeMode), "API \u8303\u56F4\u6A21\u5F0F\u65E0\u6548");
    const scopeInput = site.apiScopes ?? [];
    ensure(Array.isArray(scopeInput) && scopeInput.length <= 20 && (apiScopeMode === "all" || scopeInput.length > 0), "\u81EA\u5B9A\u4E49\u6A21\u5F0F\u8BF7\u914D\u7F6E 1 \u81F3 20 \u4E2A API \u8303\u56F4");
    const apiScopes = scopeInput.map((scope) => {
      ensure(own(scope), "API \u8303\u56F4\u65E0\u6548");
      ensure(typeof scope.pathPrefix === "string" && scope.pathPrefix.startsWith("/") && !/[?#]/.test(scope.pathPrefix) && scope.pathPrefix.length <= 512, "API \u8DEF\u5F84\u524D\u7F00\u987B\u4EE5 / \u5F00\u5934");
      return { origin: httpUrl(scope.origin).origin, pathPrefix: scope.pathPrefix };
    });
    ensure(["history", "hash"].includes(site.routeMode ?? "history"), "\u8DEF\u7531\u6A21\u5F0F\u65E0\u6548");
    ensure(["auto", "unconfigured", "public", "authorization", "session"].includes(site.identityMode ?? "auto"), "\u8EAB\u4EFD\u6A21\u5F0F\u65E0\u6548");
    const sessionPartition = String(site.sessionPartition ?? "").trim();
    ensure(sessionPartition.length <= 128 && (site.identityMode !== "session" || sessionPartition.length > 0), "\u8BF7\u4E3A Cookie \u4F1A\u8BDD\u586B\u5199\u5206\u533A\u540D\u79F0");
    const environmentId = String(site.environmentId ?? "local").trim();
    ensure(environmentId.length > 0 && environmentId.length <= 128, "\u73AF\u5883\u6807\u8BC6\u65E0\u6548");
    return { id: old?.id ?? crypto.randomUUID(), origin, environmentId, routeMode: site.routeMode ?? "history", pageIdentityQueryKeys: stringList(site.pageIdentityQueryKeys ?? []), apiScopeMode, apiScopes, cacheEnabled: site.cacheEnabled !== false, captureEnabled: site.captureEnabled !== false, identityMode: site.identityMode ?? "auto", sessionPartition, defaultTTL: ttlValue(site.defaultTTL ?? 18e5), generation: (old?.generation ?? 0) + 1, authPaths: stringList(site.authPaths ?? DEFAULT_AUTH_PATHS), floatingPosition: old?.floatingPosition };
  }
  async handleMessage(message, sender) {
    ensure(own(message) && typeof message.type === "string" && message.type.length <= 40, "\u6D88\u606F\u7ED3\u6784\u65E0\u6548");
    const payload = message.payload ?? {};
    ensure(own(payload), "\u6D88\u606F\u53C2\u6570\u65E0\u6548");
    ensure(JSON.stringify(payload).length <= 2 * MAX_BODY_BYTES + 1e5, "\u6D88\u606F\u8D85\u8FC7\u5927\u5C0F\u9650\u5236");
    if (message.type === "OPEN_OPTIONS") {
      await this.repository.run(async (session) => {
        ensure(await this.siteFor(session, sender, sender.url), "\u672A\u6388\u6743\u7F51\u7AD9");
      });
      await this.environment.openOptions?.();
      return true;
    }
    const result = await this.repository.run(async (session) => {
      const state = session.state;
      if (message.type === "OPTIONS_GET") {
        this.requireOptions(sender);
        return { sites: Object.values(state.sites), paused: state.paused };
      }
      if (message.type === "STORAGE_GET") {
        this.requireOptions(sender);
        return storageStats(state);
      }
      if (message.type === "CACHE_CLEAR_ALL") {
        this.requireOptions(sender);
        for (const rule of Object.values(state.rules)) rule.generation++;
        for (const key of Object.keys(state.index)) session.delete(key);
        state.variants = {};
        state.tickets = {};
        state.successfulSequences = {};
        state.requestFingerprints = {};
        state.missTraces = {};
        state.logs = [];
        for (const rule of Object.values(state.rules)) rememberInvalidation(state, `binding:${rule.id}`, rule.id, "CLEARED");
        return storageStats(state);
      }
      if (message.type === "API_SCOPES_GET") {
        let site2;
        if (this.isOptions(sender)) {
          site2 = typeof payload.siteId === "string" ? state.sites[payload.siteId] : void 0;
        } else {
          site2 = await this.siteFor(session, sender, payload.pageUrl ?? sender.url);
          ensure(payload.siteId === void 0 || payload.siteId === site2?.id, "\u8303\u56F4\u53D1\u73B0\u8BB0\u5F55\u4E0D\u5C5E\u4E8E\u5F53\u524D\u7F51\u7AD9");
        }
        ensure(site2, "\u7F51\u7AD9\u672A\u914D\u7F6E\u6216\u8BBF\u95EE\u6743\u9650\u5DF2\u64A4\u9500");
        return scopeDiscoveryState(state, site2);
      }
      if (message.type === "SITE_SAVE") {
        this.requireOptions(sender);
        const old = typeof payload.site?.id === "string" ? state.sites[payload.site.id] : void 0;
        const site2 = this.validateSite(payload.site, old);
        ensure(await this.environment.hasPermission(site2.origin), "\u8BF7\u5148\u6388\u4E88\u7F51\u7AD9\u8BBF\u95EE\u6743\u9650");
        ensure(!Object.values(state.sites).some((item) => item.id !== site2.id && item.origin === site2.origin), "\u8BE5\u7F51\u7AD9\u5DF2\u914D\u7F6E");
        ensure(old || Object.keys(state.sites).length < 100, "\u7F51\u7AD9\u6570\u91CF\u5DF2\u8FBE\u4E0A\u9650");
        if (old) {
          if (old.origin !== site2.origin || stableStringify([old.apiScopeMode, old.apiScopes]) !== stableStringify([site2.apiScopeMode, site2.apiScopes])) clearScopeDiscoveries(state, old.id);
          clearBindings(session, new Set(rulesForSite(session, old.id).map((rule) => rule.id)), void 0, "RULES_CHANGED");
          for (const key of Object.keys(state.identities)) if (key.startsWith(`${old.id}:`)) delete state.identities[key];
        }
        state.sites[site2.id] = site2;
        return site2;
      }
      if (message.type === "SITE_DELETE") {
        this.requireOptions(sender);
        const site2 = state.sites[payload.siteId];
        ensure(site2, "\u7F51\u7AD9\u4E0D\u5B58\u5728");
        for (const rule of rulesForSite(session, site2.id)) removeBinding(session, rule.id);
        for (const page2 of Object.values(state.pages)) if (page2.siteId === site2.id) delete state.pages[page2.id];
        for (const key of Object.keys(state.identities)) if (key.startsWith(`${site2.id}:`)) delete state.identities[key];
        clearScopeDiscoveries(state, site2.id);
        delete state.sites[site2.id];
        return true;
      }
      if (message.type === "PAUSE") {
        this.requireOptions(sender);
        ensure(typeof payload.paused === "boolean", "\u6682\u505C\u72B6\u6001\u65E0\u6548");
        state.paused = payload.paused;
        for (const site2 of Object.values(state.sites)) site2.generation++;
        return state.paused;
      }
      if (message.type === "PREPARE") return this.prepare(session, sender, payload);
      if (message.type === "COMPLETE") return this.complete(session, sender, payload);
      const site = await this.siteFor(session, sender, payload.pageUrl ?? sender.url);
      if (message.type === "PANEL" && !site) return null;
      ensure(site, "\u7F51\u7AD9\u672A\u914D\u7F6E\u6216\u8BBF\u95EE\u6743\u9650\u5DF2\u64A4\u9500");
      const activeSite = site;
      const page = getPage(session, activeSite, payload.pageUrl ?? sender.url);
      if (message.type === "PANEL") {
        return { site: activeSite, page, paused: state.paused, scopeDiscovery: scopeDiscoveryState(state, activeSite), bindings: this.pageRules(session, page).map((rule) => ({ ...rule, variants: Object.values(state.variants).filter((variant) => variant.bindingId === rule.id).sort((a, b) => (b.lastPageCallAt ?? 0) - (a.lastPageCallAt ?? 0)) })) };
      }
      if (message.type === "SITE_PATCH") {
        ensure(own(payload.patch), "\u7F51\u7AD9\u66F4\u65B0\u65E0\u6548");
        const patch = payload.patch;
        ensure(Object.keys(patch).every((key) => ["cacheEnabled", "captureEnabled", "floatingPosition"].includes(key)), "\u8BE5\u7F51\u7AD9\u8BBE\u7F6E\u53EA\u80FD\u5728\u6269\u5C55\u8BBE\u7F6E\u9875\u4FEE\u6539");
        for (const key of ["cacheEnabled", "captureEnabled"]) if (key in patch) {
          ensure(typeof patch[key] === "boolean", "\u5F00\u5173\u503C\u65E0\u6548");
          activeSite[key] = patch[key];
          activeSite.generation++;
        }
        if ("floatingPosition" in patch) {
          ensure(own(patch.floatingPosition) && [patch.floatingPosition.x, patch.floatingPosition.y].every((value) => typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 1e5), "\u6309\u94AE\u4F4D\u7F6E\u65E0\u6548");
          activeSite.floatingPosition = { x: patch.floatingPosition.x, y: patch.floatingPosition.y };
        }
        return activeSite;
      }
      if (message.type === "PAGE_PATCH") {
        ensure(own(payload.patch) && Object.keys(payload.patch).every((key) => ["cacheEnabled", "ttl"].includes(key)), "\u9875\u9762\u66F4\u65B0\u65E0\u6548");
        if ("cacheEnabled" in payload.patch) {
          ensure(typeof payload.patch.cacheEnabled === "boolean", "\u5F00\u5173\u503C\u65E0\u6548");
          page.cacheEnabled = payload.patch.cacheEnabled;
        }
        if ("ttl" in payload.patch) {
          page.ttl = payload.patch.ttl === null ? void 0 : ttlValue(payload.patch.ttl);
          clearBindings(session, new Set(this.pageRules(session, page).map((rule) => rule.id)), void 0, "RULES_CHANGED");
        }
        page.generation++;
        return page;
      }
      if (message.type === "BIND_ADD") {
        const url = httpUrl(payload.url);
        ensure(endpointInScope(url, activeSite), "\u63A5\u53E3\u4E0D\u5728\u5DF2\u914D\u7F6E API \u8303\u56F4\u5185");
        const method = String(payload.method ?? "GET").toUpperCase();
        ensure(["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"].includes(method), "\u8BF7\u6C42\u65B9\u6CD5\u65E0\u6548");
        const existing = this.pageRules(session, page).find((rule2) => rule2.method === method && rule2.apiOrigin === url.origin && rule2.pathname === url.pathname);
        if (existing) return existing;
        ensure(Object.keys(state.rules).length < MAX_RULES, "\u63A5\u53E3\u7ED1\u5B9A\u5DF2\u8FBE\u4E0A\u9650");
        const rule = defaultRule(page, method, url, String(payload.alias ?? "").slice(0, 256));
        state.rules[rule.id] = rule;
        return rule;
      }
      if (message.type === "RULE_PATCH") {
        const rule = this.scopedRule(session, page, payload.bindingId);
        this.patchRule(session, rule, payload.patch);
        return rule;
      }
      if (message.type === "BIND_DELETE") {
        const rule = this.scopedRule(session, page, payload.bindingId);
        removeBinding(session, rule.id);
        return true;
      }
      if (message.type === "CLEAR") {
        const rules = payload.bindingId ? [this.scopedRule(session, page, payload.bindingId)] : this.pageRules(session, page);
        if (payload.variantId) ensure(state.variants[payload.variantId]?.bindingId === payload.bindingId, "\u53C2\u6570\u7EC4\u5408\u4E0D\u5C5E\u4E8E\u5F53\u524D\u63A5\u53E3");
        for (const rule of rules) rule.generation++;
        clearBindings(session, new Set(rules.map((rule) => rule.id)), payload.variantId, "CLEARED");
        return true;
      }
      if (message.type === "PREVIEW") {
        const rule = this.scopedRule(session, page, payload.bindingId);
        ensure(state.variants[payload.variantId]?.bindingId === rule.id, "\u53C2\u6570\u7EC4\u5408\u4E0D\u5C5E\u4E8E\u5F53\u524D\u63A5\u53E3");
        const available = Object.values(state.index).filter((index) => index.variantId === payload.variantId).sort((a, b) => b.lastAccessedAt - a.lastAccessedAt);
        const identityPrefix = `${identityKeyFor(activeSite.id, sender, rule.apiOrigin)}:`;
        const identityScopes = new Set(sender.documentId ? Object.entries(state.identities).filter(([key]) => key.startsWith(identityPrefix)).map(([, value]) => value) : []);
        for (const index of available) {
          const entry = await session.get(index.key);
          if (entry && identityScopes.has(entry.identityScope)) return { bodyText: entry.bodyText, cachedAt: index.preview ? void 0 : entry.cachedAt };
        }
        return { bodyText: "\u6682\u65E0\u5F53\u524D\u8EAB\u4EFD\u7684\u54CD\u5E94\u9884\u89C8\uFF0C\u8BF7\u5148\u4ECE\u9875\u9762\u89E6\u53D1\u8BF7\u6C42" };
      }
      throw new Error("\u4E0D\u652F\u6301\u7684\u6D88\u606F\u7C7B\u578B");
    });
    if (["SITE_SAVE", "SITE_DELETE"].includes(message.type)) {
      const sites = await this.repository.run(async (session) => Object.values(session.state.sites));
      await this.environment.synchronizeSites?.(sites);
    }
    return result;
  }
  patchRule(session, rule, input) {
    ensure(own(input), "\u63A5\u53E3\u89C4\u5219\u65E0\u6548");
    const patch = input;
    const forceChanged = "forceCache" in patch && Boolean(patch.forceCache) !== Boolean(rule.forceCache);
    const allowed = ["alias", "enabled", "forceCache", "alwaysBypass", "readOnly", "ignoreQueryKeys", "ignoreBodyPointers", "varyHeaders", "successCondition", "ttl", "allowNoStore", "invalidateBindingIds"];
    ensure(Object.keys(patch).every((key) => allowed.includes(key)), "\u4E0D\u53EF\u4FEE\u6539\u63A5\u53E3\u8EAB\u4EFD\u5B57\u6BB5");
    if ("alias" in patch) {
      ensure(typeof patch.alias === "string" && patch.alias.length <= 256, "\u522B\u540D\u8FC7\u957F");
      rule.alias = patch.alias;
    }
    for (const key of ["enabled", "forceCache", "alwaysBypass", "readOnly", "allowNoStore"]) if (key in patch) {
      ensure(typeof patch[key] === "boolean", "\u89C4\u5219\u5F00\u5173\u65E0\u6548");
      rule[key] = patch[key];
    }
    if (patch.forceCache === true) {
      const site = session.state.sites[session.state.pages[rule.pageId]?.siteId];
      ensure(site && !rule.alwaysBypass && !isAuthPath(rule.pathname, site.authPaths) && (rule.method === "GET" || rule.method === "POST" && rule.readOnly), "\u4EC5\u666E\u901A GET \u6216\u5141\u8BB8\u7F13\u5B58\u7684 POST \u63A5\u53E3\u53EF\u5F00\u542F\u5F3A\u5236\u7F13\u5B58");
    }
    for (const key of ["ignoreQueryKeys", "ignoreBodyPointers", "varyHeaders", "invalidateBindingIds"]) if (key in patch) rule[key] = stringList(patch[key]);
    for (const pointer of rule.ignoreBodyPointers) pointerParts(pointer);
    ensure(rule.varyHeaders.every((header) => /^[a-z0-9-]+$/i.test(header) && !isSensitiveKey(header)), "\u5339\u914D\u5934\u4E0D\u80FD\u5305\u542B Authorization\u3001Cookie \u6216\u654F\u611F\u51ED\u8BC1");
    for (const id of rule.invalidateBindingIds) ensure(session.state.rules[id]?.pageId === rule.pageId, "\u5199\u540E\u6E05\u7A7A\u7684\u63A5\u53E3\u987B\u5C5E\u4E8E\u5F53\u524D\u9875\u9762");
    if ("successCondition" in patch) {
      if (patch.successCondition == null) delete rule.successCondition;
      else {
        ensure(own(patch.successCondition) && typeof patch.successCondition.pointer === "string" && patch.successCondition.value !== void 0 && JSON.stringify(patch.successCondition.value).length < 4096, "\u4E1A\u52A1\u6210\u529F\u6761\u4EF6\u65E0\u6548");
        if (patch.successCondition.pointer !== "") pointerParts(patch.successCondition.pointer);
        rule.successCondition = { pointer: patch.successCondition.pointer, value: patch.successCondition.value };
      }
    }
    if ("ttl" in patch) rule.ttl = patch.ttl === null ? void 0 : ttlValue(patch.ttl);
    if (Object.keys(patch).some((key) => key !== "alias")) rule.generation++;
    if (Object.keys(patch).some((key) => !["alias", "enabled", "alwaysBypass"].includes(key))) {
      rule.ruleVersion++;
      clearBindings(session, /* @__PURE__ */ new Set([rule.id]), void 0, forceChanged ? "FORCE_MODE_CHANGED" : "RULES_CHANGED");
    }
  }
  async prepare(session, sender, request) {
    const state = session.state;
    const site = await this.siteFor(session, sender, request.pageUrl);
    if (!site || state.paused || !site.captureEnabled) return { action: "ignore", reason: state.paused ? "\u6269\u5C55\u5DF2\u6682\u505C" : "\u7F51\u7AD9\u672A\u542F\u7528\u91C7\u96C6\u6216\u672A\u6388\u6743" };
    ensure(typeof request.requestId === "string" && request.requestId.length >= 8 && request.requestId.length <= 128, "\u8BF7\u6C42 ID \u65E0\u6548");
    ensure(request.source === "page" || request.source === "manual", "\u8BF7\u6C42\u6765\u6E90\u65E0\u6548");
    const url = httpUrl(request.url);
    if (!endpointInScope(url, site) || /(?:\.(?:js|css|map|png|jpg|gif|svg|ico|woff2?)$|\/__vite|\/@vite)/i.test(url.pathname)) return { action: "ignore", reason: "\u4E0D\u5728 API \u8303\u56F4\u5185" };
    const method = String(request.method).toUpperCase();
    ensure(/^[A-Z]{1,16}$/.test(method) && own(request.headers) && Object.keys(request.headers).length <= 100 && Object.values(request.headers).every((value) => typeof value === "string" && value.length <= 16384), "\u8BF7\u6C42\u63CF\u8FF0\u65E0\u6548");
    ensure(["omit", "same-origin", "include"].includes(request.credentials), "\u8BF7\u6C42\u51ED\u8BC1\u6A21\u5F0F\u65E0\u6548");
    ensure(request.body === void 0 || typeof request.body === "string", "\u8BF7\u6C42\u4F53\u65E0\u6548");
    if (request.body && bytes(request.body) > MAX_BODY_BYTES) return { action: "ignore", reason: "\u8BF7\u6C42\u4F53\u8D85\u8FC7 1 MiB" };
    const headers = lower(request.headers);
    const authHash = headers.authorization ? await digest(headers.authorization) : request.identityHash;
    if (authHash !== void 0) ensure(/^[a-f0-9]{64}$/i.test(authHash), "\u8EAB\u4EFD\u6458\u8981\u65E0\u6548");
    if (request.cookieIdentityHash !== void 0) ensure(/^[a-f0-9]{64}$/i.test(request.cookieIdentityHash), "Cookie \u8EAB\u4EFD\u6458\u8981\u65E0\u6548");
    const now = this.now(), page = getPage(session, site, request.pageUrl);
    let rule = this.pageRules(session, page).find((item) => item.method === method && item.apiOrigin === url.origin && item.pathname === url.pathname);
    if (!rule) {
      ensure(Object.keys(state.rules).length < MAX_RULES, "\u63A5\u53E3\u7ED1\u5B9A\u5DF2\u8FBE\u4E0A\u9650");
      rule = defaultRule(page, method, url);
      state.rules[rule.id] = rule;
    }
    const authRequest = isAuthPath(url.pathname, site.authPaths);
    let invalidateRuntime = authRequest;
    if (authRequest) invalidateSite(session, site);
    let identityScope, browserSessionId2;
    if (authHash) identityScope = `authorization:${authHash}`;
    else if (site.identityMode === "auto") {
      try {
        browserSessionId2 = await this.environment.getBrowserSessionId?.();
      } catch {
      }
      if (typeof browserSessionId2 === "string" && browserSessionId2.length > 0 && browserSessionId2.length <= 256 && Number.isInteger(sender.tab?.id) && sender.tab.id >= 0) {
        identityScope = `tab-session:${await digest(stableStringify([browserSessionId2, sender.tab.id, request.cookieIdentityHash ?? ""]))}`;
      }
    } else if (site.identityMode === "public") identityScope = "public";
    else if (site.identityMode === "session" && site.sessionPartition) identityScope = `session:${await digest(site.sessionPartition)}`;
    const contextHeaderNames = [...new Set(rule.varyHeaders.map((key) => key.toLowerCase()))].sort();
    if (identityScope) identityScope += `:context:${await digest(stableStringify(contextHeaderNames.map((key) => [key, headers[key] ?? null])))}`;
    const identityKind = authHash ? "credential" : site.identityMode === "auto" ? "auto-cookie" : site.identityMode;
    const identityBase = identityKeyFor(site.id, sender, url.origin);
    const identityChannel = await digest(stableStringify([identityKind, request.credentials, contextHeaderNames]));
    const identityKey = `${identityBase}:${identityChannel}`;
    delete state.identities[identityBase];
    const priorIdentity = state.identities[identityKey];
    if (identityScope) {
      if (priorIdentity && priorIdentity !== identityScope) {
        invalidateSite(session, site);
        invalidateRuntime = true;
      }
      state.identities[identityKey] = identityScope;
    } else if (priorIdentity) {
      invalidateSite(session, site);
      invalidateRuntime = true;
      delete state.identities[identityKey];
    }
    const safe = !authRequest && !rule.alwaysBypass && (method === "GET" || method === "POST" && rule.readOnly);
    const unsafeHeaders = Object.keys(headers).some((header) => /csrf|xsrf|signature/i.test(header));
    let reason = request.unsupportedReason || (authRequest ? "\u9274\u6743\u63A5\u53E3\u59CB\u7EC8\u76F4\u901A" : !safe ? "POST \u7F13\u5B58\u5DF2\u5173\u95ED\u3001\u5199\u64CD\u4F5C\u6216\u59CB\u7EC8\u76F4\u901A\u63A5\u53E3" : !identityScope ? site.identityMode === "auto" ? "\u65E0\u6CD5\u8BC6\u522B\u5F53\u524D\u6D4F\u89C8\u5668\u4F1A\u8BDD\uFF0C\u6682\u4E0D\u7F13\u5B58" : "\u8BF7\u5148\u914D\u7F6E\u8EAB\u4EFD\u9694\u79BB\u65B9\u5F0F" : unsafeHeaders ? "\u4E00\u6B21\u6027\u7B7E\u540D\u6216 CSRF \u4E0A\u4E0B\u6587\u4E0D\u652F\u6301\u56DE\u653E" : void 0);
    let normalized, requestBodySupported = true, parts;
    try {
      parts = normalizedRequestParts(request.url, request.body, headers, rule);
      normalized = parts.normalized;
    } catch {
      requestBodySupported = false;
      normalized = stableStringify([method, url.origin, url.pathname, url.search, request.body ?? null]);
      reason ||= "\u8BF7\u6C42\u4F53\u4E0D\u662F\u6709\u6548 JSON";
    }
    const normalizedKey = await digest(stableStringify([request.credentials, normalized]));
    const variantId = await digest(`${rule.id}:${normalizedKey}`);
    const priorVariants = Object.values(state.variants).filter((item) => item.bindingId === rule.id);
    const oldFingerprint = state.requestFingerprints[variantId] ?? priorVariants.map((item) => state.requestFingerprints[item.id]).filter((item) => !!item).sort((a, b) => b.sequence - a.sequence)[0];
    let fingerprint;
    if (parts) {
      const [query, body, matchedHeaders, identity, browserSession] = await Promise.all([digest(parts.query), digest(parts.body), digest(parts.headers), digest(identityScope ?? "unknown"), browserSessionId2 ? digest(browserSessionId2) : Promise.resolve(void 0)]);
      fingerprint = { query, body, headers: matchedHeaders, identity, session: browserSession, credentials: request.credentials, tabId: sender.tab.id, ruleVersion: rule.ruleVersion, sequence: ++state.fingerprintSequence };
    }
    let variant = state.variants[variantId];
    const hadVariant = !!variant;
    if (!variant) {
      if (Object.keys(state.variants).length >= MAX_VARIANTS) {
        const oldest = Object.values(state.variants).sort((a, b) => (a.lastCompletedAt ?? 0) - (b.lastCompletedAt ?? 0))[0];
        clearBindings(session, /* @__PURE__ */ new Set([oldest.bindingId]), oldest.id);
        forgetVariantDiagnostics(state, oldest.id);
        delete state.variants[oldest.id];
      }
      variant = { id: variantId, bindingId: rule.id, normalizedKey, url: redactUrl(request.url), body: redactBody(request.body), lastStatus: "BYPASS", hitCount: 0 };
      state.variants[variantId] = variant;
    }
    const previousStatus = variant.lastStatus, previouslyCached = variant.cachedAt !== void 0;
    const observationSequence = ++state.sequence;
    variant.lastObservedSequence = observationSequence;
    variant.url = redactUrl(request.url);
    variant.body = redactBody(request.body);
    if (request.source === "page") variant.lastPageCallAt = now;
    const canReplay = safe && !!identityScope && !unsafeHeaders && !request.unsupportedReason && !reason;
    const cacheAllowed = !reason && site.cacheEnabled && page.cacheEnabled && rule.enabled;
    if (!reason && !cacheAllowed) reason = !site.cacheEnabled ? "\u7F51\u7AD9\u7F13\u5B58\u5173\u95ED" : !page.cacheEnabled ? "\u672C\u9875\u7F13\u5B58\u5173\u95ED" : "\u63A5\u53E3\u7F13\u5B58\u5173\u95ED";
    const cacheKey = await digest(stableStringify([1, site.id, page.id, site.environmentId, identityScope ?? "unknown", rule.ruleVersion, normalizedKey]));
    let expired = false;
    if (cacheAllowed && request.source !== "manual") {
      const cached = await session.get(cacheKey);
      if (cached && (!cached.expiresAt || cached.expiresAt > now)) {
        cached.lastAccessedAt = now;
        session.put(cacheKey, cached);
        if (request.source === "page") await recordScopeDiscovery(state, site, rule, now);
        if (fingerprint) state.requestFingerprints[variantId] = fingerprint;
        delete variant.networkReason;
        delete state.missTraces[`cache:${cacheKey}`];
        delete state.missTraces[`variant:${variantId}`];
        variant.lastStatus = "HIT";
        variant.lastCompletedAt = now;
        variant.lastDurationMs = 0;
        variant.hitCount++;
        variant.reason = "\u7F13\u5B58\u547D\u4E2D";
        delete variant.lastError;
        this.log(session, request.requestId, rule.id, request.source, "HIT", now);
        return { action: "hit", entry: cached, bindingId: rule.id, variantId, canReplay, replayReason: canReplay ? void 0 : reason, invalidateRuntime };
      }
      if (cached) {
        expired = true;
        session.delete(cacheKey);
        delete variant.cachedAt;
        delete variant.expiresAt;
        delete variant.sizeBytes;
      }
    }
    let diagnostic;
    const cacheTraceKey = `cache:${cacheKey}`, variantTraceKey = `variant:${variantId}`, bindingTraceKey = `binding:${rule.id}`;
    const trace = state.missTraces[cacheTraceKey] ?? state.missTraces[variantTraceKey] ?? state.missTraces[bindingTraceKey];
    const changed = fingerprint ? fingerprintChange(oldFingerprint, fingerprint) : void 0;
    if (request.source === "manual") diagnostic = networkReason("MANUAL");
    else if (reason) diagnostic = networkReason(["\u7F51\u7AD9\u7F13\u5B58\u5173\u95ED", "\u672C\u9875\u7F13\u5B58\u5173\u95ED", "\u63A5\u53E3\u7F13\u5B58\u5173\u95ED"].includes(reason) ? "CACHE_DISABLED" : "BYPASS", reason);
    else if (expired) diagnostic = networkReason("EXPIRED");
    else if (trace && trace.code !== "IDENTITY_CHANGED") diagnostic = networkReason(trace.code);
    else if (changed && ["HEADERS_CHANGED", "CREDENTIALS_CHANGED", "SESSION_CHANGED", "IDENTITY_CHANGED"].includes(changed.code)) diagnostic = changed;
    else if (trace) diagnostic = networkReason(trace.code);
    else if (Object.values(state.tickets).some((active) => active.cacheKey === cacheKey && active.cacheAllowed && now - active.startedAt <= 10 * 6e4 && active.siteGeneration === site.generation && active.pageGeneration === page.generation && active.ruleGeneration === rule.generation)) diagnostic = networkReason("IN_FLIGHT");
    else if (!priorVariants.length) diagnostic = networkReason("FIRST_REQUEST");
    else if (changed) diagnostic = changed;
    else if (hadVariant && oldFingerprint && !previouslyCached && ["ERROR", "BYPASS"].includes(previousStatus)) diagnostic = networkReason("NOT_RECORDED");
    else diagnostic = networkReason("UNAVAILABLE", oldFingerprint ? "\u6CA1\u6709\u627E\u5230\u5F53\u524D\u5339\u914D\u6761\u4EF6\u4E0B\u53EF\u7528\u7684\u7F13\u5B58\u3002" : "\u5386\u53F2\u8BF7\u6C42\u5C1A\u65E0\u53C2\u6570\u6458\u8981\uFF0C\u65E0\u6CD5\u786E\u5B9A\u6B64\u524D\u672A\u547D\u4E2D\u7684\u539F\u56E0\u3002");
    if (!reason) {
      delete state.missTraces[cacheTraceKey];
      delete state.missTraces[variantTraceKey];
      delete state.missTraces[bindingTraceKey];
    }
    if (fingerprint) state.requestFingerprints[variantId] = fingerprint;
    variant.networkReason = diagnostic;
    variant.lastNetworkAttemptAt = now;
    variant.lastStatus = "PENDING";
    variant.reason = reason;
    delete variant.lastError;
    for (const ticket2 of Object.values(state.tickets)) if (now - ticket2.startedAt > 10 * 6e4) delete state.tickets[ticket2.id];
    if (Object.keys(state.tickets).length >= 2e3) delete state.tickets[Object.keys(state.tickets)[0]];
    const ticket = { id: crypto.randomUUID(), siteId: site.id, pageId: page.id, bindingId: rule.id, variantId, cacheKey, identityScope: identityScope ?? "unknown", siteGeneration: site.generation, pageGeneration: page.generation, ruleGeneration: rule.generation, sequence: observationSequence, networkReason: diagnostic, cacheAllowed: !!cacheAllowed, source: request.source, startedAt: now, reason, tabId: sender.tab.id, documentId: sender.documentId, origin: site.origin, authRequest, discoveryAllowed: request.source === "page" && safe && !request.unsupportedReason && !unsafeHeaders && requestBodySupported };
    state.tickets[ticket.id] = ticket;
    return { action: "network", ticket, reason, networkReason: diagnostic, bindingId: rule.id, variantId, canReplay, replayReason: canReplay ? void 0 : reason, invalidateRuntime };
  }
  log(session, requestId, bindingId, source, status, at, reason) {
    session.state.logs.push({ requestId, bindingId, source, status, at, reason: reason?.slice(0, 200) });
    session.state.logs = session.state.logs.slice(-200);
  }
  async complete(session, sender, completion) {
    const state = session.state;
    ensure(own(completion.ticket) && typeof completion.ticket.id === "string", "\u8BF7\u6C42\u7968\u636E\u65E0\u6548");
    const ticket = state.tickets[completion.ticket.id];
    if (!ticket) return { saved: false, success: false, reason: "\u8BF7\u6C42\u7968\u636E\u5DF2\u8FC7\u671F\u6216\u5DF2\u5B8C\u6210" };
    const site = await this.siteFor(session, sender, ticket.origin);
    ensure(site?.id === ticket.siteId && ticket.tabId === sender.tab?.id && ticket.documentId === sender.documentId, "\u8BF7\u6C42\u7968\u636E\u6765\u6E90\u4E0D\u5339\u914D");
    delete state.tickets[ticket.id];
    const rule = state.rules[ticket.bindingId], page = state.pages[ticket.pageId], variant = state.variants[ticket.variantId];
    if (!site || !rule || !page || !variant) return { saved: false, success: false, reason: "\u8BF7\u6C42\u6240\u5C5E\u7ED1\u5B9A\u5DF2\u5220\u9664" };
    ensure(Number.isInteger(completion.status) && completion.status >= 0 && completion.status <= 599 && own(completion.headers) && Object.keys(completion.headers).length <= 100 && Object.values(completion.headers).every((value) => typeof value === "string" && value.length <= 16384), "\u54CD\u5E94\u63CF\u8FF0\u65E0\u6548");
    const now = this.now(), headers = lower(completion.headers);
    let reason = completion.error ? "\u771F\u5B9E\u8BF7\u6C42\u5931\u8D25\u6216\u5DF2\u53D6\u6D88" : completion.status < 200 || completion.status >= 300 ? `HTTP ${completion.status}` : void 0;
    let parsed, jsonValid = false;
    if (completion.bodyText !== void 0) {
      ensure(typeof completion.bodyText === "string", "\u54CD\u5E94\u6B63\u6587\u65E0\u6548");
      try {
        parsed = JSON.parse(completion.bodyText);
        jsonValid = true;
      } catch {
      }
    }
    if (!reason && rule.successCondition && (!jsonValid || valueAtPointer(parsed, rule.successCondition.pointer) === void 0 || stableStringify(valueAtPointer(parsed, rule.successCondition.pointer)) !== stableStringify(rule.successCondition.value))) reason = "\u672A\u6EE1\u8DB3\u4E1A\u52A1\u6210\u529F\u6761\u4EF6";
    const success = !reason;
    const invalidateRuntime = ticket.authRequest || completion.status === 401 || completion.status === 403;
    if (invalidateRuntime) invalidateSite(session, site);
    if (success && !["GET", "HEAD", "OPTIONS"].includes(rule.method) && !(rule.method === "POST" && rule.readOnly)) {
      for (const bindingId of rule.invalidateBindingIds) {
        const affected = state.rules[bindingId];
        if (affected?.pageId === rule.pageId) {
          affected.generation++;
          clearBindings(session, /* @__PURE__ */ new Set([bindingId]), void 0, "CLEARED");
        }
      }
    }
    let recordReason = reason || completion.unsupportedReason;
    if (!recordReason && [204, 206].includes(completion.status)) recordReason = "204 / \u90E8\u5206\u54CD\u5E94\u4E0D\u5F55\u5236";
    if (!recordReason && (completion.redirected || ["opaque", "opaqueredirect", "error"].includes(completion.responseType ?? ""))) recordReason = "\u91CD\u5B9A\u5411\u6216 opaque \u54CD\u5E94\u4E0D\u5F55\u5236";
    if (!recordReason && !/\b(?:application|text)\/(?:[a-z0-9.+-]*\+)?json\b/i.test(headers["content-type"] ?? "")) recordReason = "\u4EC5\u5F55\u5236 JSON \u54CD\u5E94";
    if (!recordReason && !jsonValid) recordReason = "\u54CD\u5E94\u4E0D\u662F\u6709\u6548 JSON";
    if (!recordReason && completion.bodyText !== void 0 && bytes(completion.bodyText) > MAX_BODY_BYTES) recordReason = "\u54CD\u5E94\u8D85\u8FC7 1 MiB";
    if (!recordReason && /(?:^|,)\s*no-store\b/i.test(headers["cache-control"] ?? "") && !rule.allowNoStore) recordReason = "\u54CD\u5E94 no-store\uFF0C\u672A\u5F00\u542F\u5141\u8BB8\u5F55\u5236";
    const current = !state.paused && site.captureEnabled && site.generation === ticket.siteGeneration && page.generation === ticket.pageGeneration && rule.generation === ticket.ruleGeneration;
    if (!recordReason && !current) recordReason = "\u8BF7\u6C42\u671F\u95F4\u914D\u7F6E\u3001\u8EAB\u4EFD\u6216\u7F13\u5B58\u5DF2\u53D8\u66F4";
    if (!recordReason && ticket.authRequest) recordReason = "\u9274\u6743\u63A5\u53E3\u4E0D\u4FDD\u5B58\u54CD\u5E94";
    let saved = false;
    if (!recordReason && completion.bodyText !== void 0) {
      if (ticket.discoveryAllowed) await recordScopeDiscovery(state, site, rule, now);
      const visibleHeaders = Object.fromEntries(Object.entries(headers).filter(([key]) => !isSensitiveKey(key) && !["content-length", "content-encoding", "transfer-encoding", "connection"].includes(key)));
      const ttl = rule.ttl ?? page.ttl ?? site.defaultTTL;
      const entry = { cacheKey: ticket.cacheKey, bindingId: rule.id, variantId: variant.id, identityScope: ticket.identityScope, bodyText: completion.bodyText, status: completion.status, statusText: String(completion.statusText).slice(0, 256), headers: visibleHeaders, cachedAt: now, expiresAt: ttl === 0 ? 0 : now + ttl, sizeBytes: bytes(completion.bodyText), lastAccessedAt: now, sequence: ticket.sequence };
      if (ticket.cacheAllowed && site.cacheEnabled && page.cacheEnabled && rule.enabled && !rule.alwaysBypass) {
        const previous = await session.get(ticket.cacheKey);
        const newestSuccess = Math.max(previous?.sequence ?? 0, state.successfulSequences[ticket.cacheKey]?.sequence ?? 0);
        if (ticket.sequence > newestSuccess) {
          session.put(ticket.cacheKey, entry);
          state.successfulSequences[ticket.cacheKey] = { sequence: ticket.sequence, variantId: variant.id };
          variant.cachedAt = now;
          variant.expiresAt = entry.expiresAt;
          variant.sizeBytes = entry.sizeBytes;
          saved = true;
          const watermarks = Object.entries(state.successfulSequences);
          if (watermarks.length > 6e3) {
            const activeKeys = new Set(Object.values(state.tickets).map((active) => active.cacheKey));
            let count = watermarks.length;
            for (const [key] of watermarks.sort((a, b) => a[1].sequence - b[1].sequence)) {
              if (count <= 6e3) break;
              if (!activeKeys.has(key)) {
                delete state.successfulSequences[key];
                count--;
              }
            }
          }
        } else recordReason = "\u8F83\u65B0\u7684\u8BF7\u6C42\u5DF2\u6210\u529F\u66F4\u65B0\u7F13\u5B58";
      } else {
        const key = `preview:${variant.id}`;
        const previous = await session.get(key);
        if (!previous || ticket.sequence > previous.sequence) session.put(key, entry, true);
        recordReason = ticket.reason ?? "\u7F13\u5B58\u5173\u95ED\uFF0C\u5DF2\u66F4\u65B0\u54CD\u5E94\u9884\u89C8";
      }
      evictToBudget(session);
    }
    const completedStatus = !success ? "ERROR" : saved ? "MISS" : "BYPASS";
    const completedReason = recordReason ?? ticket.reason ?? "\u771F\u5B9E\u8BF7\u6C42\u5E76\u5F55\u5236";
    if (variant.lastObservedSequence === void 0 || variant.lastObservedSequence === ticket.sequence) {
      variant.lastCompletedAt = now;
      variant.lastDurationMs = Number.isFinite(completion.durationMs) ? Math.max(0, completion.durationMs) : now - ticket.startedAt;
      variant.lastStatus = completedStatus;
      variant.reason = completedReason;
      if (!success) variant.lastError = reason;
      else delete variant.lastError;
    }
    this.log(session, ticket.id, rule.id, ticket.source, completedStatus, now, completedReason);
    return { saved, success, reason: completedReason, invalidateRuntime };
  }
};

// src/background/index.ts
var repository = new IndexedDBRepository();
var browserSessionId;
function getBrowserSessionId() {
  return browserSessionId ??= (async () => {
    const key = "apiCacheReplayBrowserSessionId";
    const existing = (await chrome.storage.session.get(key))[key];
    if (typeof existing === "string" && existing.length) return existing;
    const value = crypto.randomUUID();
    await chrome.storage.session.set({ [key]: value });
    return value;
  })().catch((error) => {
    browserSessionId = void 0;
    throw error;
  });
}
var registrationQueue = Promise.resolve();
async function synchronizeSites(sites) {
  const job = registrationQueue.then(async () => {
    const allowed = [];
    for (const site of sites) if (await chrome.permissions.contains({ origins: [originPattern(site.origin)] })) allowed.push(site);
    const matches = [...new Set(allowed.map((site) => originPattern(site.origin)))];
    const existing = await chrome.scripting.getRegisteredContentScripts();
    const managed = existing.filter((script) => script.id.startsWith("api-cache-replay-")).map((script) => script.id);
    if (managed.length) await chrome.scripting.unregisterContentScripts({ ids: managed });
    if (matches.length) await chrome.scripting.registerContentScripts([
      { id: "api-cache-replay-main", matches, js: ["main.js"], runAt: "document_start", world: "MAIN", allFrames: false, persistAcrossSessions: true },
      { id: "api-cache-replay-content", matches, js: ["content.js"], runAt: "document_start", world: "ISOLATED", allFrames: false, persistAcrossSessions: true }
    ]);
  });
  registrationQueue = job.catch(() => void 0);
  return job;
}
var core = new CacheCore(repository, {
  extensionId: chrome.runtime.id,
  getBrowserSessionId,
  hasPermission: (origin) => chrome.permissions.contains({ origins: [originPattern(origin)] }),
  synchronizeSites,
  openOptions: () => chrome.runtime.openOptionsPage()
});
async function handleMessage(message, sender) {
  try {
    const data = await core.handleMessage(message, sender);
    if (message.type === "PANEL" && data) Object.assign(data, { extensionVersion: chrome.runtime.getManifest().version });
    if (["SITE_SAVE", "SITE_DELETE", "PAUSE", "SITE_PATCH", "PAGE_PATCH", "RULE_PATCH", "CLEAR", "CACHE_CLEAR_ALL", "BIND_ADD", "BIND_DELETE"].includes(message.type)) {
      await chrome.storage.local.set({ revision: crypto.randomUUID() });
    }
    return { ok: true, data };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "\u6269\u5C55\u5904\u7406\u5931\u8D25" };
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  void handleMessage(message, sender).then(sendResponse);
  return true;
});
async function refreshRegistration() {
  try {
    const sites = await repository.run(async (session) => Object.values(session.state.sites));
    await synchronizeSites(sites);
  } catch (error) {
    console.warn("API Cache Replay: \u65E0\u6CD5\u6CE8\u518C\u5185\u5BB9\u811A\u672C", error);
  }
}
chrome.runtime.onInstalled.addListener(() => {
  void refreshRegistration();
});
chrome.runtime.onStartup.addListener(() => {
  void refreshRegistration();
});
chrome.permissions.onAdded.addListener(() => {
  void refreshRegistration();
});
chrome.permissions.onRemoved.addListener(() => {
  void repository.run(async (session) => {
    for (const site of Object.values(session.state.sites)) if (!await chrome.permissions.contains({ origins: [originPattern(site.origin)] })) site.generation++;
  }).then(async () => {
    await chrome.storage.local.set({ revision: crypto.randomUUID() });
    await refreshRegistration();
  });
});
chrome.action.onClicked.addListener(() => {
  void chrome.runtime.openOptionsPage();
});
export {
  handleMessage
};
//# sourceMappingURL=background.js.map
